package org.icse2020.axeray;

import org.locationtech.jts.geom.*;
import org.locationtech.jts.index.strtree.GeometryItemDistance;
import org.locationtech.jts.index.strtree.STRtree;
import org.opencv.core.Mat;
import jsat.DataSet;
import jsat.SimpleDataSet;
import jsat.classifiers.CategoricalData;
import jsat.classifiers.DataPoint;
import jsat.clustering.Clusterer;
import jsat.clustering.HDBSCAN;
import jsat.linear.DenseVector;
import jsat.linear.Vec;
import jsat.linear.distancemetrics.DistanceMetric;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import java.awt.Rectangle;
import java.util.*;
import java.util.concurrent.ExecutorService;

public class Cluster {
    public List<ROI> ROIs;
    public Cluster parent;
    public List<Cluster> children;
    public GeometryFactory geometryFactory;

    public Cluster(List<ROI> ROIs) {
        this.ROIs = ROIs;
        this.parent = null;
        this.children = new ArrayList<>();
        this.geometryFactory = new GeometryFactory(new PrecisionModel(1));
    }

    public void populateDefaultClusters() {
        if (ROIs.size()>1) {
            this.children = new ArrayList<>(ROIs.size());
            for (ROI R : ROIs) {
                List<ROI> list = new ArrayList<>(1);
                list.add(R);
                this.children.add(new Cluster(list));
            }
        } else {
            this.children = null;
        }
    }

    public List<Geometry> getROIsAsGeometryList() {
        List<Geometry> result = new ArrayList<>(ROIs.size());
        for (ROI R : ROIs) {
            result.add(geometryFactory.createPolygon(new Coordinate[]{new Coordinate(R.x1, R.y1),
                    new Coordinate(R.x2, R.y1),
                    new Coordinate(R.x2, R.y2),
                    new Coordinate(R.x1, R.y2),
                    new Coordinate(R.x1, R.y1)}));
        }
        return result;
    }

    public Map<String, Object> getStats() {
        List<Integer> yDiff = new ArrayList<>(ROIs.size()*ROIs.size()*4);
        List<Integer> xDiff = new ArrayList<>(ROIs.size()*ROIs.size()*4);
        for (ROI A : ROIs) {
            for (ROI B : ROIs) {
                if (A.equals(B)) {
                    continue;
                } else {
                    List<Integer> ydiffs = Arrays.asList(Math.abs(A.y1-B.y1), Math.abs(A.y1-B.y2),
                                                         Math.abs(A.y2-B.y1), Math.abs(A.y2-B.y2));
                    List<Integer> xdiffs = Arrays.asList(Math.abs(A.x1-B.x1), Math.abs(A.x1-B.x2),
                                                         Math.abs(A.x2-B.x1), Math.abs(A.x2-B.x2));
                    yDiff.addAll(ydiffs);
                    xDiff.addAll(xdiffs);
                }
            }
        }
        Map<String, Object> result = new HashMap<>(2);
        result.put("yDiff", yDiff);
        result.put("xDiff", xDiff);
        return result;
    }

    public List<Double> getAlignmentStats() {
        List<Geometry> objects = getROIsAsGeometryList();
        List<Double> deltas = new ArrayList<>(ROIs.size()*ROIs.size());
        for (Geometry A : objects) {
            for (Geometry B : objects) {
                if (A.equals(B)) {
                    continue;
                } else {
                    List<Double> deltasAB = Arrays.asList(
                            Math.abs(A.getEnvelopeInternal().getMinX()-B.getEnvelopeInternal().getMinX()),
                            Math.abs(A.getEnvelopeInternal().getMaxX()-B.getEnvelopeInternal().getMaxX()),
                            Math.abs(A.getEnvelopeInternal().getMinY()-B.getEnvelopeInternal().getMinY()),
                            Math.abs(A.getEnvelopeInternal().getMaxY()-B.getEnvelopeInternal().getMaxY()),
                            Math.abs(A.getCentroid().getX() - B.getCentroid().getX()),
                            Math.abs(A.getCentroid().getY() - B.getCentroid().getY())
                            );
                    double delta = Collections.min(deltasAB);
                    if (delta>=1) deltas.add(delta);
                }
            }
        }
        return deltas;
    }

    public Map<String, List<Double>> getGeomStats() {
        List<Geometry> objects = getROIsAsGeometryList();
        List<Double> distances = new ArrayList<>(ROIs.size()*ROIs.size());
        for (Geometry A : objects) {
            for (Geometry B : objects) {
                if (A.equals(B)) {
                    continue;
                } else {
                    distances.add(A.distance(B));
                }
            }
        }
        Map<String, List<Double>> result = new HashMap<>(2);
        result.put("diff", distances);
        return result;
    }

    public Map<String, Object> buildAdjacencyNeighborhood() {
        STRtree tree = new STRtree();
        Map<Polygon, ROI> treeMapping = new HashMap<>(ROIs.size());
        for (ROI R : ROIs) {
            Polygon P = geometryFactory.createPolygon(new Coordinate[]{new Coordinate(R.x1, R.y1),
                    new Coordinate(R.x2, R.y1), new Coordinate(R.x2, R.y2), new Coordinate(R.x1, R.y2),
                    new Coordinate(R.x1, R.y1)});
            treeMapping.put(P, R);
            tree.insert(P.getEnvelopeInternal(), P);
        }

        Map<Polygon, List<Polygon>> adjacency = new HashMap<>(treeMapping.keySet().size());
        for (Polygon P : treeMapping.keySet()) {
            List<Polygon> adjacents = new ArrayList<>(10);
            Object[] _NN = tree.nearestNeighbour(P.getEnvelopeInternal(), P, new GeometryItemDistance(), 10);
            List<Polygon> NN = new ArrayList<>(_NN.length);
            for (Object _N : _NN) { NN.add((Polygon)_N); }

            for (Polygon neighbor : NN) {
                if (neighbor.equals(P)) {
                    continue;
                } else {
                    LineString scanLine = geometryFactory.createLineString(new Coordinate[]{
                            P.getCentroid().getCoordinate(), neighbor.getCentroid().getCoordinate()
                    });
                    List<Polygon> scanQuery = tree.query(scanLine.getEnvelopeInternal());
                    if (scanQuery.size()==2) {
                        adjacents.add(neighbor);
                    } else {
                        continue;
                    }
                }
            }
            adjacency.put(P, adjacents);
        }

        Map<ROI, List<ROI>> ROIsAdjacency = new HashMap<>(adjacency.size());
        for (Polygon P : adjacency.keySet()) {
            ROI R = treeMapping.get(P);
            List<ROI> list = new ArrayList<>(adjacency.get(P).size());
            for (Polygon l : adjacency.get(P)) {
                list.add(treeMapping.get(l));
            }
            ROIsAdjacency.put(R, list);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("ROIsAdjacency", ROIsAdjacency);
        result.put("polygonAdjacency", adjacency);
        return result;
    }

    public Map<String, List<Double>> getAdjacencyStats() {
        List<Double> distances = new ArrayList<>(ROIs.size()*ROIs.size());
        List<Double> deltas = new ArrayList<>(ROIs.size()*ROIs.size());
        Map<String, Object> raw = buildAdjacencyNeighborhood();
        Map<Polygon, List<Polygon>> adjacency = (Map<Polygon, List<Polygon>>)(raw.get("polygonAdjacency"));
        for (Polygon A : adjacency.keySet()) {
            for (Polygon B : adjacency.get(A)) {
                List<Double> deltasAB = Arrays.asList(
                        Math.abs(A.getEnvelopeInternal().getMinX()-B.getEnvelopeInternal().getMinX()),
                        Math.abs(A.getEnvelopeInternal().getMaxX()-B.getEnvelopeInternal().getMaxX()),
                        Math.abs(A.getEnvelopeInternal().getMinY()-B.getEnvelopeInternal().getMinY()),
                        Math.abs(A.getEnvelopeInternal().getMaxY()-B.getEnvelopeInternal().getMaxY()),
                        Math.abs(A.getCentroid().getX() - B.getCentroid().getX()),
                        Math.abs(A.getCentroid().getY() - B.getCentroid().getY())
                );
                deltas.add(Collections.min(deltasAB));
                distances.add(A.distance(B));
            }
        }
        Map<String, List<Double>> result = new HashMap<>(2);
        result.put("distances", distances);
        result.put("deltas", deltas);
        return result;
    }


    public List<String> getXPaths() {
        List<String> xpaths = new ArrayList<>();
        for (ROI R : ROIs) {
            xpaths.add(R.xpath);
        }
        return xpaths;
    }

    public int getSize() {
        return ROIs.size();
    }

    public void add(ROI R) {
        ROIs.add(R);
    }

    public void remove(ROI R) {
        ROIs.remove(R);
    }

    public Rectangle getMBR(int offset) {
        List<Integer> x = new ArrayList<>(ROIs.size()*2);
        List<Integer> y = new ArrayList<>(ROIs.size()*2);
        for (ROI R : ROIs) {
            x.add(R.x1); x.add(R.x2);
            y.add(R.y1); y.add(R.y2);
        }
        int x1 = Collections.min(x) - offset, x2 = Collections.max(x) + offset;
        int y1 = Collections.min(y) - offset, y2 = Collections.max(y) + offset;
        return new Rectangle(x1, y1, (x2-x1), (y2-y1));
    }

    public Mat renderOn(Mat overlay) {
        Scalar borderROI = new Scalar(2, 166, 249, 255);
        Scalar borderCluster = new Scalar(87, 139, 46, 255);
        for (ROI R : ROIs) {
            Imgproc.rectangle(overlay, new Point(R.x1, R.y1), new Point(R.x2, R.y2), borderROI, 1);
        }
        Rectangle mbr = getMBR(2);
        Imgproc.rectangle(overlay, new Point(mbr.x, mbr.y), new Point(mbr.x+mbr.width, mbr.y+mbr.height), borderCluster, 3);
        return overlay;
    }

    public List<Cluster> findClusters() {
        class DPrime implements DistanceMetric {
            @Override public boolean isSymmetric() { return true; }
            @Override public double metricBound() { return Double.POSITIVE_INFINITY; }
            @Override public boolean isSubadditive() { return true; }
            @Override public boolean isIndiscemible() { return true; }
            @Override public String toString() { return "DPrime"; }
            @Override public DPrime clone() { return new DPrime(); }
            @Override public boolean supportsAcceleration() { return false; }
            @Override public List<Double> getAccelerationCache(List<? extends Vec> vecs) { return null; }
            @Override public List<Double> getAccelerationCache(List<? extends Vec> list, ExecutorService executorService) { return null; }
            @Override public List<Double> getQueryInfo(Vec vec) { return null; }
            @Override public double dist(int a, int b, List<? extends Vec> vecs, List<Double> cache) { return dist(vecs.get(a), vecs.get(b)); }
            @Override public double dist(int a, Vec b, List<? extends Vec> vecs, List<Double> cache) { return dist(a, b, getQueryInfo(b), vecs, cache); }
            @Override public double dist(int a, Vec b, List<Double> qi, List<? extends Vec> vecs, List<Double> cache) { return dist(vecs.get(a), b); }

            private final GeometryFactory geometryFactory;
            public DPrime() {
                super();
                geometryFactory = new GeometryFactory(new PrecisionModel(1));
            }

            @Override public double dist(Vec a, Vec b) {
                ROI A = ROIs.get((int)(a.get(0)));
                ROI B = ROIs.get((int)(b.get(0)));
                return distanceMetric(A, B)+pathMetric(A, B);
            }

            public double distanceMetric(ROI A, ROI B) {
                Coordinate[] A_shell = {new Coordinate(A.x1, A.y1), new Coordinate(A.x2, A.y1),
                                         new Coordinate(A.x2, A.y2), new Coordinate(A.x1, A.y2),
                                                                    new Coordinate(A.x1, A.y1)};
                Coordinate[] B_shell = {new Coordinate(B.x1, B.y1), new Coordinate(B.x2, B.y1),
                                         new Coordinate(B.x2, B.y2), new Coordinate(B.x1, B.y2),
                                                                    new Coordinate(B.x1, B.y1)};
                Polygon A_poly = geometryFactory.createPolygon(A_shell);
                Polygon B_poly = geometryFactory.createPolygon(B_shell);
                return A_poly.distance(B_poly);
            }

            public double pathMetric(ROI A, ROI B) {
                String A_xpath = A.xpath;
                String B_xpath = B.xpath;
                int diff = A_xpath.length() - B_xpath.length();
                if (diff > 0) {
                    B_xpath = String.format("%-"+(A_xpath.length())+"s", B_xpath);
                }
                if (diff < 0) {
                    A_xpath = String.format("%-"+(B_xpath.length())+"s", A_xpath);
                }
                int score = 0;
                for (int c=0; c<A_xpath.length(); c++) {
                    score += (A_xpath.charAt(c) != B_xpath.charAt(c)) ? 1 : 0;
                }
                return score*1;
            }
        }

        List<DataPoint> dataPoints = new ArrayList<DataPoint>(this.ROIs.size());
        int[] categoricalValues = new int[0];
        CategoricalData[] categoricalData = {};
        for (int r=0; r<this.ROIs.size(); r++) {
            DenseVector numericalValues = new DenseVector(1);
            numericalValues.set(0, (double) r);
            dataPoints.add(new DataPoint(numericalValues, categoricalValues, categoricalData));
        }
        DataSet dataset = new SimpleDataSet(dataPoints);

        Clusterer hdbscan = new HDBSCAN(new DPrime(), 3);

        List<List<DataPoint>> pointClusters = hdbscan.cluster(dataset);
        List<Cluster> clusters = new ArrayList<>(pointClusters.size());

        for (List<DataPoint> points : pointClusters) {
            List<ROI> clusterROIs = new ArrayList<>(points.size());
            for (int p=0; p<points.size(); p++) {
                Vec vector = points.get(p).getNumericalValues();
                int index = (int)(vector.get(0));
                clusterROIs.add(this.ROIs.get(index));
            }
            Cluster x = new Cluster(clusterROIs);
            x.parent = this;
            this.children.add(x);
            clusters.add(x);
        }
        return clusters;
    }
}