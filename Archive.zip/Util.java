package org.icse2020.axeray;

import org.opencv.core.*;
import org.opencv.core.Point;
import org.opencv.imgcodecs.Imgcodecs;
import org.bytedeco.javacpp.Loader;
import org.bytedeco.opencv.opencv_java;
import org.opencv.imgproc.Imgproc;
import org.openqa.selenium.JavascriptExecutor;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class Util {

    public static Mat readImageBuffer(byte[] buffer) {
        return Imgcodecs.imdecode(new MatOfByte(buffer), Imgcodecs.IMREAD_UNCHANGED);
    }

    public static byte[] convertMatToPNG(Mat image) {
        MatOfByte buffer = new MatOfByte();
        Imgcodecs.imencode(".png", image, buffer);
        return buffer.toArray();
    }

    public static String readFile(File file) throws IOException {
        byte[] encoded = Files.readAllBytes(file.toPath());
        return new String(encoded);
    }

    public static String readFile(String path) throws IOException {
        byte[] encoded = Files.readAllBytes(Paths.get(path));
        return new String(encoded);
    }

    public static BufferedImage convertMatToBufferedImage(Mat matrix) {
        int type;
        switch (matrix.channels()) {
            case 3:
                type = BufferedImage.TYPE_3BYTE_BGR;
                break;

            case 4:
                List<Mat> src = new ArrayList<>();
                List<Mat> dest = new ArrayList<>();
                src.add(matrix);
                dest.add(matrix.clone());
                MatOfInt mix = new MatOfInt();
                int[] order = {0,1 , 1,2 , 2,3 , 3,0};
                mix.fromArray(order);
                Core.mixChannels(src, dest, mix);
                matrix = dest.get(0);
                type = BufferedImage.TYPE_4BYTE_ABGR;
                break;

            default:
                type = BufferedImage.TYPE_BYTE_GRAY;
        }
        int bufferSize = matrix.channels()*matrix.cols()*matrix.rows();
        byte[] b = new byte[bufferSize];
        matrix.get(0, 0, b);
        BufferedImage image = new BufferedImage(matrix.cols(), matrix.rows(), type);
        final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        System.arraycopy(b, 0, targetPixels, 0, b.length);
        return image;
    }
    static { Loader.load(opencv_java.class); }
    public static void displaySVG(Browser viewer, String SVG, String title) throws Exception {
        Path tempFile = Files.createTempFile(title+"__", ".html");
        String location = tempFile.toString();
        File outputFile = new File(location);
        FileWriter writer = new FileWriter(outputFile, false);
        writer.write(SVG);
        writer.close();
        JavascriptExecutor js = (JavascriptExecutor) viewer;
        js.executeScript("window.open();");
        List<String> tabs = new ArrayList<>(viewer.getWindowHandles());
        viewer.switchTo().window(tabs.get(tabs.size()-1));
        viewer.get("file://" + location);
        Files.delete(tempFile);
    }

    public static void displayMat(Browser viewer, String title, Mat sshot) throws Exception {
        int scrWidth = sshot.cols(), scrHeight = sshot.rows();
        byte[] screenshotBytes = convertMatToPNG(sshot);
        StringBuilder sb = new StringBuilder();
        String b64 = Base64.getEncoder().encodeToString(screenshotBytes);
        String image = "<image x=\"0\" y=\"0\" width=\""+scrWidth+"\" height=\""+scrHeight+"\" xlink:href=\"data:image/png;base64,"+b64+"\" />\n";
        sb.append(image);
        String SVGContent = sb.toString();
        String output = "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n" +
                "<svg viewBox=\"0 0 "+scrWidth+" "+scrHeight+"\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xml:space=\"preserve\">\n"+SVGContent+"\n</svg>";
        displaySVG(viewer, output, title);
    }

    public static void displayROIs(Browser viewer, String title, Mat sshot, List<ROI> ROIs) throws Exception {
        int yOffset = 20;
        Mat screenshot = new Mat(sshot.rows()+yOffset, sshot.cols(), sshot.type());
        Core.copyMakeBorder(sshot, screenshot, yOffset, 0,0,0, Core.BORDER_REPLICATE);
        int scrWidth = screenshot.cols(), scrHeight = screenshot.rows();
        byte[] screenshotBytes = convertMatToPNG(screenshot);
        StringBuilder sb = new StringBuilder();
        String b64 = Base64.getEncoder().encodeToString(screenshotBytes);
        String image = "<image x=\"0\" y=\"0\" width=\""+scrWidth+"\" height=\""+scrHeight+"\" xlink:href=\"data:image/png;base64,"+b64+"\" />\n";

        sb.append(image);
        int colorIndex = 0;
        String label="";
        int labelX=0, labelY=0, fontSize=16;
        double strokeWidth = 0.5;
        int labelCounter = 1;

        Rectangle box = new Rectangle();
        for (ROI R : ROIs) {
                box = R.getBBox();
                int x = box.x, y = box.y, width = box.width, height = box.height;
                y = y + yOffset;
                String fill = "#" + Colormap.getHex(colorIndex);
                sb.append("<rect x=\"" + x + "\" y=\"" + y + "\" width=\"" + width + "\" height=\"" + height + "\" fill=\"" + fill + "\" fill-opacity=\"0.33\" stroke-opacity=\"100%\" stroke=\"rgb(0,0,0)\" stroke-width=\"" + strokeWidth + "\"></rect>\n");
                colorIndex++;

        }
        String SVGContent = sb.toString();
        scrHeight = 15000;
        String output = "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n" +
                "<svg viewBox=\"0 0 "+scrWidth+" "+scrHeight+"\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xml:space=\"preserve\">\n"+SVGContent+"\n</svg>";
        displaySVG(viewer, output, title);
    }

    public static void displayGroups(Browser browser, Group group) throws IOException {
        List<Group> holder = new ArrayList<>();
        holder.add(group);
        displayGroups(browser, holder);
    }

    public static void displayGroups(Browser browser, List<Group> groups) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (Group G : groups) {
            browser.executeScript("((x, y, w, h) => {\n" +
                    "const palette = [\n" +
                    "\"#660000\", \"#806060\", \"#e56739\", \"#f2a200\", \"#3a5916\", \"#3ad900\", \"#00add9\", \"#4040ff\", \"#361040\", \"#994d94\", \"#ff0066\"\n" +
                    "]\n" +
                    "\n" +
                    "color = palette[Math.floor(Math.random() * palette.length)]\n" +
                    "const highlight = document.createElement('div')\n" +
                    "highlight.style['position'] = 'absolute'\n" +
                    "highlight.style['left'] = (window.scrollX + x)+\"px\"\n" +
                    "highlight.style['width'] = w+\"px\"\n" +
                    "highlight.style['top'] = (window.scrollY + y)+\"px\"\n" +
                    "highlight.style['height'] = h+\"px\"\n" +
                    "highlight.style['z-index'] = 10000000\n" +
                    "highlight.style['border'] = 'dashed black 2px'\n" +
                    "highlight.style['background-color'] = \n" +
                    "\"\"+color+\"77\"\n" +
                    "highlight.id = \"_cortex_highlight_\"+Math.floor(Math.random()*1000000000)\n" +
                    "document.body.appendChild(highlight)\n" +
                    "})("+G.bbox.x+", "+G.bbox.y+", "+G.bbox.width+", "+G.bbox.height+")");
        }
    }

    public static String overlayAsSVG(Mat sshot, List<List<Group>> tree) throws IOException {
        int yOffset = 20;
        Mat screenshot = new Mat(sshot.rows()+yOffset, sshot.cols(), sshot.type());
        Core.copyMakeBorder(sshot, screenshot, yOffset, 0,0,0, Core.BORDER_REPLICATE);
        int scrWidth = screenshot.cols(), scrHeight = screenshot.rows();
        byte[] screenshotBytes = convertMatToPNG(screenshot);
        StringBuilder sb = new StringBuilder();
        String b64 = Base64.getEncoder().encodeToString(screenshotBytes);
        String image = "<image x=\"0\" y=\"0\" width=\""+scrWidth+"\" height=\""+scrHeight+"\" xlink:href=\"data:image/png;base64,"+b64+"\" />\n";

        sb.append(image);
        int colorIndex = 0;
        String label="";
        int labelX=0, labelY=0, fontSize=16;
        double strokeWidth = 0.5;
        int labelCounter = 1;

        Rectangle box = new Rectangle();
        for (List<Group> levelGroups : tree) {
            for (Group G : levelGroups) {
                if (G.level == 1) box = padRect(G.bbox, 5, screenshot);
                if (G.level == 2) box = padRect(G.bbox, -2, screenshot);
                int x = box.x, y = box.y, width = box.width, height = box.height;
                y = y + yOffset;
                String fill = "#" + Colormap.getHex(colorIndex);
                if (G.level == 1) strokeWidth = 4;
                if (G.level == 2) strokeWidth = 2;
                sb.append("<rect x=\"" + x + "\" y=\"" + y + "\" width=\"" + width + "\" height=\"" + height + "\" fill=\"" + fill + "\" fill-opacity=\"0.33\" stroke-opacity=\"100%\" stroke=\"rgb(0,0,0)\" stroke-width=\"" + strokeWidth + "\"></rect>\n");
                colorIndex++;
            }
        }

        for (List<Group> levelGroups : tree) {
            for (Group G : levelGroups) {
                if (G.level == 1) box = padRect(G.bbox, 5, screenshot);
                if (G.level == 2) box = padRect(G.bbox, -2, screenshot);
                int x = box.x, y = box.y, width = box.width, height = box.height;
                y = y + yOffset;

                if (G.level == 1) labelX = x + 5;
                if (G.level == 2) labelX = x + (width / 2) - 100;
                if (G.level == 1) labelY = y - 5;
                if (G.level == 2) labelY = y + 20;

                if (G.level == 2 && G.role.equals("region")) {
                    label = "sub-region within main content";
                }  else if (G.level==1 && G.role.equals("region")) {
                    label = "";
                } else if (G.level==1 && G.role.equals("main")) {
                    label = "main content";
                } else {
                    label = G.role;
                }
                if (G.level==1) fontSize = 16;
                if (G.level==2) fontSize = 12;
                sb.append("<text x=\""+labelX+"\" y=\""+labelY+"\" fill=\"rgb(0,0,0)\" stroke=\"rgb(191,0,255)\" stroke-width=\"7\" font-family=\"Arial\" font-weight=\"900\" font-size=\""+fontSize+"\">#"+labelCounter+" "+label+"</text>");
                sb.append("<text x=\""+labelX+"\" y=\""+labelY+"\" fill=\"rgb(0,0,0)\" stroke=\"rgb(191,255,0)\" stroke-width=\"4\" font-family=\"Arial\" font-weight=\"900\" font-size=\""+fontSize+"\">#"+labelCounter+" "+label+"</text>");
                sb.append("<text x=\""+labelX+"\" y=\""+labelY+"\" fill=\"rgb(0,0,0)\" stroke=\"rgb(255,191,0)\" stroke-width=\"0.1\" font-family=\"Sans-serif\" font-weight=\"900\" font-size=\""+fontSize+"\">#"+labelCounter+" "+label+"</text>");
                labelCounter++;
            }
        }
        String SVGContent = sb.toString();
        String output = "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n" +
                "<svg viewBox=\"0 0 "+scrWidth+" "+scrHeight+"\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xml:space=\"preserve\">\n"+SVGContent+"\n</svg>";

        return output;
    }

    public static Rectangle padRect(Rectangle R, int pad, Mat screenshot) {
        Rectangle newRect = new Rectangle(R.x-pad, R.y-pad, R.width+pad, R.height+pad);
        newRect.x = Math.max(newRect.x, 0);
        newRect.y = Math.max(newRect.y, 0);
        if (newRect.x+newRect.width>screenshot.cols()) newRect.width = screenshot.cols();
        if (newRect.y+newRect.height>screenshot.rows()) newRect.height = screenshot.rows();
        return newRect;
    }

    public static Scalar getRandomColor() {
        Random r = new Random();
        return new Scalar(r.nextInt(156)+100, r.nextInt(156)+100, r.nextInt(156)+100);
    }

    public static Scalar getRandomFillColor() {
        Random r = new Random();
        return new Scalar(r.nextInt(156), r.nextInt(156), r.nextInt(156), 255);
    }

    public static Mat drawRect(Mat image, Rectangle rect, Scalar color, int thickness) {
        Mat output = image.clone();
        int x1 = rect.x, x2 = rect.x+rect.width;
        int y1 = rect.y, y2 = rect.y+rect.height;
        Imgproc.rectangle(output, new Point(x1,y1), new Point(x2,y2), color, thickness);
        return output;
    }

    public static Mat drawRect(Mat image, Rectangle rect, int thickness) {
        return drawRect(image, rect, getRandomColor(), thickness);
    }

    public static Mat drawRect(Mat image, Rectangle rect, Scalar color) {
        return drawRect(image, rect, color, 3);
    }

    public static Mat drawRect(Mat image, Rectangle rect) {
        return drawRect(image, rect, getRandomColor(), 3);
    }

    public static void displayMat(Mat matrix, String title, boolean scaled) {
        Mat newMatrix;
        if (scaled==true) {
            Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
            int maxHeight = screen.height-50;
            int maxWidth = screen.width-50;
            double aspectRatio = matrix.rows()/matrix.cols();
            double scale;
            Size newSize;
            if (aspectRatio>1) { // tall
                if (matrix.rows()>maxHeight) {
                    scale = maxHeight/matrix.rows();
                    newSize = new Size(scale*matrix.cols(), maxHeight);
                } else {
                    newSize = matrix.size();
                }
            } else { // wide
                if (matrix.cols()>maxWidth) {
                    scale = maxWidth/matrix.cols();
                    newSize = new Size(maxWidth, scale*matrix.rows());
                } else {
                    newSize = matrix.size();
                }
            }
            newMatrix = new Mat(newSize, CvType.CV_8UC3);
            Imgproc.resize(matrix, newMatrix, newSize);
        } else {
            newMatrix = matrix.clone();
        }
        BufferedImage image = convertMatToBufferedImage(newMatrix);
        ImageIcon icon = new ImageIcon(image);
        JLabel lbl = new JLabel();
        lbl.setIcon(icon);
        JPanel container = new JPanel();
        container.add(lbl);
        JScrollPane scrollPane = new JScrollPane(container);
        scrollPane.getVerticalScrollBar().setUnitIncrement(150);
        scrollPane.getHorizontalScrollBar().setUnitIncrement(150);
        JFrame frame = new JFrame();
        int width, height;
        width = image.getWidth(null)+50;
        height = image.getHeight(null)+50;
        frame.setSize(width, height);
        frame.add(scrollPane);
        frame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        frame.setTitle(title);
        frame.setVisible(true);
        frame.getRootPane().paintImmediately(0, 0, width, height);
        frame.getRootPane().paintImmediately(0, 0, width, height);
    }

    public static void displayMat(Mat matrix, String title) {
        displayMat(matrix, title, true);
    }

    public static void displayMat(Mat matrix) {
        displayMat(matrix, matrix.toString(), true);
    }

    public static Mat overlay(Mat A, double alpha, Mat B, double beta) throws IllegalArgumentException {
        if (A.cols()==B.cols() && A.rows()==B.rows()) {
            Mat overlay = new Mat(A.size(), A.type());
            Core.addWeighted(A, alpha, B, beta, 0.0, overlay);
            return overlay;
        } else {
            throw new IllegalArgumentException("unequal matrix size");
        }
    }

    public static void displayMat(org.bytedeco.opencv.opencv_core.Mat asMat) {
        org.opencv.core.Mat mat=new org.opencv.core.Mat(asMat.address());
        displayMat(mat);
    }
}
