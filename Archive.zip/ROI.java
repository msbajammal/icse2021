package org.icse2020.axeray;

import com.google.common.collect.ImmutableMap;
import org.locationtech.jts.geom.Envelope;
import org.locationtech.jts.index.strtree.ItemBoundable;
import org.locationtech.jts.index.strtree.ItemDistance;
import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;

import java.awt.*;
import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ROI extends ItemBoundable implements ItemDistance  {
    public int getArea() { return Math.abs(width*height); }

    @Override public String toString() {
        if (type.equals("text")) {
            String repr = "";
            if (content.length()>=20) repr = content.substring(0,20)+"...";
            if (content.length()<20) repr = content;
            return type+"["+repr+"]["+x1+" - "+x2+", "+y1+" - "+y2+"]";
        } else {
            return type + "[" + x1 + " - " + x2 + ", " + y1 + " - " + y2 + "]";
        }
    }

    public Point getCenter() {
        return new Point((int)(x1 + (width/2)), (int)(y1 + (height/2)));
    }

    public boolean isInside(Rectangle r) {
        int left = r.x; int top = r.y;
        int right = r.x+r.width; int bottom = r.y+r.height;
        if (x1 >= left  && y1 >= top &&
            x2 <= right && y2 <= bottom) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isCenteredInside(Rectangle r) {
        int left = r.x; int top = r.y;
        int right = r.x+r.width; int bottom = r.y+r.height;
        Point center = getCenter();
        return center.x >= left && center.x <= right
                && center.y >= top && center.y <= bottom;
    }
    public boolean isChildOf(String groupXpath) {
        return this.xpath.contains(groupXpath);
    }

    public Rectangle getBBox() {
        return new Rectangle(x1, y1, width, height);
    }

    //
//    private static List<ROI> _getNestedROIs(Browser browser, WebElement iframe, List<ROI> ROIs) throws IOException {
//        String rootXPath;
//        if (iframe == null) {
//            rootXPath = "";
//            ROIs = new ArrayList<>();
//            browser.switchTo().defaultContent();
//        } else {
//            rootXPath = iframe.getAttribute("xpath");
//            ROIs = ROIs;
//            browser.switchTo().frame(iframe);
//        }
//
//        _loadCortexJS(browser);
//        ROIs.addAll(_getROIsPerFrame(browser, rootXPath));
//        List<WebElement> iframes = (List<WebElement>) (browser.executeScript("return window.__CORTEXJS._findIFrames();"));
//
//        for (WebElement frame : iframes) {
//            ROIs.addAll(_getNestedROIs(browser, frame, ROIs));
//        }
//
//        return ROIs;
//    }
//
//
//    public static List<ROI> getROIs(Browser browser) throws IOException {
//        _loadCortexJS(browser);
//        String rootXPath = "";
//        List<ROI> ROIs = new ArrayList<>();
//        ROIs.addAll(_getROIsPerFrame(browser, rootXPath));
//
//        List<WebElement> iframes = (List<WebElement>) (browser.executeScript("return window.__CORTEXJS._findIFrames();"));
//        for (WebElement iframe : iframes) {
//            rootXPath = iframe.getAttribute("xpath");
//            browser.switchTo().frame(iframe);
//            ROIs.addAll(_getROIsPerFrame(browser, rootXPath));
//            browser.switchTo().defaultContent();
//        }
//
//        return ROIs;
//    }
//
//    private static List<ROI> _getROIsPerFrame(Browser browser, String rootXPath) throws IOException {
//        Map<String, Object> result = browser.evaluate("window.__CORTEXJS.getROIs();");
//        ArrayList<Map<String,Object>> mapROIs = (ArrayList<Map<String,Object>>)(((Map<String,Object>)(result.get("result"))).get("value"));
//        ArrayList<ROI> ROIs = new ArrayList<ROI>();
//        mapROIs.forEach(ROI -> {
//            String content = ROI.containsKey("content") ? (String)(ROI.get("content")) : "";
//            ROI ROIObject = new ROI(((Long)(ROI.get("x1"))).intValue(), ((Long)(ROI.get("y1"))).intValue(),
//                                    ((Long)(ROI.get("x2"))).intValue(), ((Long)(ROI.get("y2"))).intValue(),
//                                    ((Long)(ROI.get("width"))).intValue(), ((Long)(ROI.get("height"))).intValue(),
//                                    (String)(ROI.get("type")), rootXPath+(String)(ROI.get("xpath")), content);
//            ROIs.add(ROIObject);
//        });
//        return ROIs;
//    }
    public String getColor() {
        return "("+this.foregroundColor[0]+", "+this.foregroundColor[1]+", "+this.foregroundColor[2]+")";
    }
    public int x1, y1, x2, y2, width, height, zOrder=0, fontSize;
    public final String type, xpath, content, href;
    public final int[] foregroundColor, backgroundColor;
    public final int documentWidth, documentHeight;
    public final boolean isClickable;
    public final long area;
//    public double normalizedArea = 0.0; // computed on 2nd pass

    public static Mat renderROIs(java.util.List<ROI> ROIs) throws IOException {
        return renderROIs(ROIs, true);
    }

    public static Mat renderROIs(java.util.List<ROI> ROIs, boolean random) throws IOException {
        Mat ROIImage = new Mat(ROIs.get(0).documentHeight, ROIs.get(0).documentWidth, CvType.CV_8UC3);
        Scalar color;
        Scalar border = new Scalar(0,0,0);

        int drawCount = 0, zLevel = 0;

        while (drawCount!=ROIs.size()) {
            for (ROI R : ROIs) {
                if (R.zOrder==zLevel) {
                    if (random) {
                        color = Util.getRandomColor();
                    } else {
                        switch (R.type) {
                            case "text":
                                color = new Scalar(0, 255, 0); // BGR
                                break;
                            case "image":
                                color = new Scalar(255, 0, 0);
                                break;
                            case "input":
                                color = new Scalar(0, 0, 255);
                                break;
                            default:
                                color = new Scalar(0, 0, 0);
                        }
                    }
                    Imgproc.rectangle(ROIImage, new org.opencv.core.Point(R.x1, R.y1), new org.opencv.core.Point(R.x2, R.y2), color, -1);
                    Imgproc.rectangle(ROIImage, new org.opencv.core.Point(R.x1, R.y1), new org.opencv.core.Point(R.x2, R.y2), border, 1);
                    drawCount++;
                }
            }
            zLevel++;
        }

        return ROIImage;
    }

    public static java.util.List<ROI> generateAll(Browser browser) throws IOException {
        _loadCortexJS(browser);
        java.util.List<ROI> ROIs = new ArrayList<>();

        Map<String, Object> layout = browser.send("Page.getLayoutMetrics");
        int fullWidth = ((Long)((Map<String, Object>)layout.get("contentSize")).get("width")).intValue();
        int fullHeight = ((Long)((Map<String, Object>)layout.get("contentSize")).get("height")).intValue();
        int windowWidth = ((Long)((Map<String, Object>)layout.get("visualViewport")).get("clientWidth")).intValue();
        int windowHeight = ((Long)((Map<String, Object>)layout.get("visualViewport")).get("clientHeight")).intValue();

        browser.send("Emulation.setDeviceMetricsOverride",
                ImmutableMap.of("width", fullWidth, "height", fullHeight,
                        "deviceScaleFactor", Long.valueOf(1), "mobile", Boolean.FALSE,
                        "fitWindow", Boolean.FALSE)
        );
        browser.send("Emulation.setVisibleSize", ImmutableMap.of("width", fullWidth,
                "height", fullHeight));

        java.util.List<Map<String, Object>> mapROIs = (java.util.List<Map<String, Object>>)(browser.executeScript("return window.__CORTEXJS.getROIs();"));
        mapROIs.forEach(ROI -> {
            String content = ROI.containsKey("content") ? (String)(ROI.get("content")) : "";
            int fontSize = ((Long)(ROI.get("fontSize"))).intValue();
            java.util.List<Long> rawForegroundColor = (java.util.List<Long>)(ROI.get("foregroundColor"));
            java.util.List<Long> rawBackgroundColor = (java.util.List<Long>)(ROI.get("backgroundColor"));
            int[] foregroundColor = {rawForegroundColor.get(0).intValue(),
                    rawForegroundColor.get(1).intValue(),
                    rawForegroundColor.get(2).intValue(),
                    rawForegroundColor.get(3).intValue()};
            int[] backgroundColor = {rawBackgroundColor.get(0).intValue(),
                    rawBackgroundColor.get(1).intValue(),
                    rawBackgroundColor.get(2).intValue(),
                    rawBackgroundColor.get(3).intValue()};
            boolean isClickable = (boolean)(ROI.get("isClickable"));
            String href = (String)(ROI.get("href"));

            ROI ROIObject = new ROI(((Long)(ROI.get("x1"))).intValue(), ((Long)(ROI.get("y1"))).intValue(),
                    ((Long)(ROI.get("x2"))).intValue(), ((Long)(ROI.get("y2"))).intValue(),
                    ((Long)(ROI.get("width"))).intValue(), ((Long)(ROI.get("height"))).intValue(),
                    (String)(ROI.get("type")), (String)(ROI.get("xpath")), content,
                    fontSize, foregroundColor, backgroundColor, fullWidth, fullHeight, isClickable, href);
            ROIs.add(ROIObject);
        });

        browser.send("Emulation.setVisibleSize", ImmutableMap.of(
                "x", Long.valueOf(0), "y", Long.valueOf(0),
                "width", windowWidth, "height", windowHeight));

        browser.send("Emulation.setDeviceMetricsOverride",
                ImmutableMap.of("width", 0, "height", 0,
                        "deviceScaleFactor", 0, "mobile", Boolean.FALSE,
                        "fitWindow", Boolean.FALSE)
        );

        return ROIs;
    }

    public static void _loadCortexJS(Browser browser) throws IOException {
        File cortexjsFile = new File(ClassLoader.getSystemClassLoader().getResource("cortex.js").getFile());
        String cortexjs = Util.readFile(cortexjsFile);
//        browser.evaluate(cortexjs);
        browser.executeScript(cortexjs);
        if ((Boolean)(browser.executeScript("return window.__CORTEXJS == undefined"))) {
            throw new RuntimeException("Unable to load CortexJS");
        }
    }


    public static Rectangle getBounds(java.util.List<ROI> ROIs) {
        int left=0, top=0, right=0, bottom=0;
        for (ROI R : ROIs) {
            if (R.x1 < left) left = R.x1;
            if (R.y1 < top) top = R.y1;
            if (R.x2 > right) right = R.x2;
            if (R.y2 > bottom) bottom = R.y2;
        }
        return new Rectangle(left, top, right-left, bottom-top);

    }

    public static java.util.List<ROI> verify(java.util.List<ROI> rawROIs, Mat screenshot) {
        java.util.List<ROI> ROIs = new ArrayList<>(rawROIs.size());
        Mat structure = new Mat(screenshot.size(), CvType.CV_8UC1);
        Imgproc.cvtColor(screenshot, structure, Imgproc.COLOR_BGR2GRAY);
        Imgproc.Canny(structure, structure, 50, 50);
        Mat sub=null; double m; int width, height;
        for (ROI R : rawROIs) {
            if (Math.max(R.x1, 0) + R.width > structure.cols()) {
                width = Math.max(structure.cols()-Math.max(R.x1, 0),0);
            } else {
                width = Math.max(R.width,0);
            }
            if (Math.max(R.y1, 0) + R.height > structure.rows()) {
                height = Math.max(structure.rows()-Math.max(R.y1, 0),0);
            } else {
                height = Math.max(R.height,0);
            }
            if (R.x1 > structure.cols() || R.y1 > structure.rows() || R.width<1 || R.height<1) {
                continue;
            }
            try {
                sub = structure.submat(new Rect(Math.max(R.x1, 0),
                        Math.max(R.y1, 0),
                        width, height));
            } catch (CvException e) {
                e.printStackTrace();
            }
            if (R.type.contains("input") || sub!=null && hasContent(sub)) {
                ROIs.add(R);
            }
        }
        return ROIs;
    }

    public ROI(int x1, int y1, int x2, int y2, int width, int height,
               String type, String xpath, String content,
               int fontSize, int[] foregroundColor, int[] backgroundColor,
               int documentWidth, int documentHeight, boolean isClickable, String href) {
        super(new Rectangle(x1, y1, width, height), xpath);
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.width = width;
        this.height = height;
        this.area = width*height;
        this.type = type;
        this.xpath = xpath;
        this.content = content;
        this.fontSize = fontSize;
        this.foregroundColor = foregroundColor;
        this.backgroundColor = backgroundColor;
        this.documentWidth = documentWidth;
        this.documentHeight = documentHeight;
        this.isClickable = isClickable;
        this.href = href;
    }

    public ROI(ROI copy) {
        super(new Rectangle(copy.x1, copy.y1, copy.width, copy.height), copy.xpath);
        this.x1 = copy.x1;
        this.y1 = copy.y1;
        this.x2 = copy.x2;
        this.y2 = copy.y2;
        this.width = copy.width;
        this.height = copy.height;
        this.area = copy.width*copy.height;
        this.type = copy.type;
        this.xpath = copy.xpath;
        this.content = copy.content;
        this.fontSize = copy.fontSize;
        this.foregroundColor = copy.foregroundColor.clone();
        this.backgroundColor = copy.backgroundColor.clone();
        this.documentWidth = copy.documentWidth;
        this.documentHeight = copy.documentHeight;
        this.isClickable = copy.isClickable;
        this.href = copy.href;
    }

    public static boolean hasContent(Mat ROI) {
        int stripSizeY = ROI.rows()/10;
        int stripSizeX = ROI.cols()/10;
        Mat topStrip =     ROI.submat(new Rect(0,0, ROI.cols(), stripSizeY));
        Mat bottomStrip =  ROI.submat(new Rect(0,ROI.rows()-stripSizeY, ROI.cols(), stripSizeY));
        Mat leftStrip =    ROI.submat(new Rect(0,0, stripSizeX, ROI.rows()));
        Mat rightStrip =   ROI.submat(new Rect(ROI.cols()-stripSizeX,0, stripSizeX, ROI.rows()));
        Mat center    =    ROI.submat(new Rect(stripSizeX, stripSizeY, ROI.cols()-stripSizeX, ROI.rows()-stripSizeY));
        if (Core.countNonZero(topStrip)*100>topStrip.total()
                && Core.countNonZero(rightStrip)*100>rightStrip.total()
                && Core.countNonZero(bottomStrip)*100>bottomStrip.total()
                && Core.countNonZero(leftStrip)*100>leftStrip.total()) {
            return true;
        }
        if (Core.countNonZero(center)*100>center.total()) {
            return true;
        }
        return false;
    }

    public static java.util.List<ROI> trim(java.util.List<ROI> ROIs, Mat screen) {
        java.util.List<ROI> trimmed = new ArrayList<>(ROIs.size());
        int left, top, right, bottom, width, height, x1, x2, y1, y2;
        ROI RR;
        for (ROI R : ROIs) {
            x1 = Math.max(R.x1, 0); y1 = Math.max(R.y1, 0);
            x2 = Math.max(R.x2, 0); y2 = Math.max(R.y2, 0);
            x1 = Math.min(x1, screen.cols());
            y1 = Math.min(y1, screen.rows());
            x2 = Math.min(x2, screen.cols());
            y2 = Math.min(y2, screen.rows());

            RR = new ROI(R);
            RR.x1 = x1; RR.x2 = x2;
            RR.y1 = y1; RR.y2 = y2;
            RR.width = x2-x1; RR.height = y2-y1;
            trimmed.add(RR);
        }
        return trimmed;
    }

//    public static List<ROI> getFrameROIs(Browser browser, String xPathPrefix) throws IOException {
//        _loadCortexJS(browser);
//        List<Map<String, Object>> mapROIs = (List<Map<String, Object>>)(browser.executeScript("return window.__CORTEXJS.getROIs();"));
//        List<ROI> ROIs = new ArrayList<>();
//        mapROIs.forEach(ROI -> {
//            String content = ROI.containsKey("content") ? (String)(ROI.get("content")) : "";
//            ROI ROIObject = new ROI(((Long)(ROI.get("x1"))).intValue(), ((Long)(ROI.get("y1"))).intValue(),
//                    ((Long)(ROI.get("x2"))).intValue(), ((Long)(ROI.get("y2"))).intValue(),
//                    ((Long)(ROI.get("width"))).intValue(), ((Long)(ROI.get("height"))).intValue(),
//                    (String)(ROI.get("type")), xPathPrefix+(String)(ROI.get("xpath")), content);
//            ROIs.add(ROIObject);
//        });
//        return ROIs;
//    }
//
//    public static List<ROI> getNetROIs(Browser browser) throws IOException {
//        List<ROI> all = new ArrayList<>();
//
//        class Helper {
//            int removedIFramesCounter = 0;
//            public void getDescendants(String xPathRel, String xPathAbs) throws IOException {
//            if (xPathAbs.equals("") && xPathRel.equals("")) {
//                browser.switchTo().defaultContent();
//                WebElement parentFrame = browser.findElementByXPath("/html[1]/body[1]");
//                browser.switchTo().frame(parentFrame);
//            } else {
//                try {
//                    WebElement parentFrame = browser.findElementByXPath(xPathRel);
//                    browser.switchTo().frame(parentFrame);
//                } catch (Exception e) { // iframe was removed
//                    System.out.print("Couldn't find "+xPathRel);
//                    removedIFramesCounter++;
//                    System.out.println(".   "+removedIFramesCounter+" so far.");
//                    return;
//                }
//            }
//            all.addAll(getFrameROIs(browser, xPathAbs));
//
//            List<String> childIFramesXPaths = (List<String>) (browser.executeScript("return window.__CORTEXJS._findIFrames();"));
//            for (String xpath : childIFramesXPaths) {
//                getDescendants(xpath, xPathAbs+xpath);
//            }
//
//        }}
//
//        new Helper().getDescendants("", "");
//        return all;
//    }

    public static java.util.List<ROI> filterByType(java.util.List<ROI> ROIs, String[] filter) {
        java.util.List<ROI> results = new ArrayList<>(ROIs.size());
        for (ROI R : ROIs) {
            for (String f : filter) {
                if (R.type.contains(f)) {
                    results.add(R);
                }
            }
        }
        return results;
    }

    public static java.util.List<ROI> verifyOverlaps(java.util.List<ROI> ROIs, Mat screenshot, Browser browser) throws IOException {
        Set<ROI> verified = new HashSet<>(ROIs.size());
        Mat overlapMap = new Mat(screenshot.size(), CvType.CV_8UC1, Scalar.all(0));
        for (ROI R : ROIs) {
            Core.add(overlapMap, new Scalar(1), overlapMap, getMask(R, screenshot));
        }
        Core.MinMaxLocResult minmax = Core.minMaxLoc(overlapMap);
        int max = (int)minmax.maxVal;
        java.util.List<MatOfPoint> contours = new ArrayList<>();
        Rectangle rect; java.awt.Point center;
        Mat levelCut = new Mat(overlapMap.size(), CvType.CV_8UC1, Scalar.all(0));
        java.util.List<ROI> verifiedROIsPerLevel;
        for (int x = max; x>0; x--) {
            Core.inRange(overlapMap, new Scalar(x), new Scalar(x), levelCut);
            Imgproc.findContours(levelCut, contours, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
            for (MatOfPoint C : contours) {
                rect = getContourAsRect(C);
                center = new java.awt.Point((int)rect.getCenterX(), (int)rect.getCenterY());
                verified.addAll(filterByLocation(browser, center, ROIs));
            }
            contours.clear();
        }
        return new ArrayList<>(verified);
    }

    public static java.util.List<ROI> filterByLocation(Browser browser, java.awt.Point location, java.util.List<ROI> allGlobalROIs) throws IOException {
        _loadCortexJS(browser);
        int x = location.x, y = location.y;
        java.util.List<ROI> result = new ArrayList<>(allGlobalROIs.size());
        java.util.List<String> xpaths = (java.util.List<String>)(browser.executeScript(
                "return window.__CORTEXJS._retrieveByLocation("+x+", "+y+");"));
        if (xpaths!=null) {
            for (int i = 0; i<xpaths.size(); i++) {
                for (ROI R : allGlobalROIs) {
                    if (R.xpath.equals(xpaths.get(i))) {
                        ROI newR = new ROI(R);
                        newR.zOrder = xpaths.size()-1-i; // first element == highest zOrder
                        result.add(newR);
                    }
                    if (result.size()==xpaths.size()) break;
                }
                if (result.size()==xpaths.size()) break;
            }
        }
        return result;
    }

    public static Mat getMask(ROI R, Mat screenshot) {
        Mat mask = new Mat(screenshot.size(), CvType.CV_8UC1, Scalar.all(0));
        Imgproc.rectangle(mask, new org.opencv.core.Point(R.x1,R.y1), new org.opencv.core.Point(R.x2,R.y2), new Scalar(255), -1);
        return mask;
    }

    public static Rectangle getContourAsRect(MatOfPoint contour) {
        List<org.opencv.core.Point> coords = contour.toList();
        int left=1000000000, top=1000000000, right=0, bottom=0;

        for (org.opencv.core.Point p : coords) {
            if (p.x<left) left = (int)p.x;
            if (p.y<top) top = (int)p.y;

            if (p.x>right) right = (int)p.x;
            if (p.y>bottom) bottom = (int)p.y;
        }
        return new Rectangle(left, top, right-left, bottom-top);
    }

    public boolean coveredBy(Rectangle r) {
        int left = r.x; int top = r.y;
        int right = r.x+r.width; int bottom = r.y+r.height;
        int xC = x1 + (x2-x1)/2;
        int yC = y1 + (y2-y1)/2;
        return (xC <= right && xC >= left &&
                yC <= bottom && yC >= top);

    }

    @Override
    public Object getItem() {
        return this;
    }

    @Override
    public Object getBounds() {
        return new Envelope(x1, x2, y1, y2);
    }

    @Override
    public int hashCode() {
        return this.xpath.hashCode();
    }

    @Override
    public boolean equals(Object R) {
        if (!(R instanceof ROI)) {
            return false;
        } else {
            return this.xpath.equals(((ROI)R).xpath)
                    || (this.x1==((ROI) R).x1 && this.y1==((ROI) R).y1
                        && this.x2==((ROI) R).x2 && this.y2==((ROI) R).y2
                        && this.type.equals(((ROI) R).type));
        }
    }

    @Override
    public double distance(ItemBoundable A, ItemBoundable B) {
        Envelope a = (Envelope)(A.getBounds());
        Envelope b = (Envelope)(B.getBounds());
        return a.distance(b);
    }
}
