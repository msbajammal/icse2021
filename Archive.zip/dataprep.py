import os
from PIL import Image, ImageOps

raw = ['./raw/pos', './raw/neg']
final = ['./final/pos', './final/neg']

def flattenTransparency(image):
    bands = image.getbands()
    if (len(bands)==4):
        R,G,B,A = image.split()
        mask = Image.eval(A, lambda alpha: 255 if alpha==0 else 0)
        A.paste(255, box=(0,0,image.width,image.height))
        R.paste(255, box=(0,0,image.width,image.height), mask=mask)
        G.paste(255, box=(0,0,image.width,image.height), mask=mask)
        B.paste(255, box=(0,0,image.width,image.height), mask=mask)
        image = Image.merge("RGBA", (R,G,B,A))
        return image
    else:
        return image

for x in range(len(raw)):
    for r, d, f in os.walk(raw[x]): # r=root, d=directories, f = files
        for file in f:
            if '.DS_Store' not in file:
                print("---------------------------------------------------")
                input_file = os.path.join(raw[x], file)

                image = Image.open(input_file)

                print("Original channels: " + str(image.mode))
                image = flattenTransparency(image)
                image = image.convert("L")
                print("New channels: " + str(image.mode))

                image = image.resize((32, 32), Image.LANCZOS)

                output_file = os.path.join(final[x], file)
                image.save(output_file)

                image = ImageOps.mirror(image)
                orig_file = str(output_file)
                new_file = str(output_file)
                new_file = new_file.replace(".png", "-mirror.png")
                new_file = new_file.replace(".jpg", "-mirror.jpg")
                if new_file==orig_file:
                    raise Exception("couldn't write mirrored file")
                image.save(new_file)