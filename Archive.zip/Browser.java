package org.icse2020.axeray;

import java.awt.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Base64;
import java.util.List;

import com.google.common.collect.ImmutableMap;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.Response;

public class Browser extends ChromeDriver {
    public Browser() {
        this(false);
    }

    public Browser(boolean headless) {
        super(_initOptions(headless));
        java.awt.Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        manage().window().setSize(new Dimension(screen.width-150, screen.height-50));
        manage().window().setPosition(new org.openqa.selenium.Point(120,50));
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                quit();
            }
        });
        send("Page.addScriptToEvaluateOnNewDocument", ImmutableMap.of(
                "source", "const __CORTEXJS_CL__ = []\n" +
                        "const __CORTEXJS_add__ = HTMLElement.prototype.addEventListener\n" +
                        "HTMLElement.prototype.addEventListener = function(t, l, c) {\n" +
                        "    const fxn = __CORTEXJS_add__.bind(this)\n"+
                        "    if (t==='click') { __CORTEXJS_CL__.push(this) }\n" +
                        "    if (c!==undefined) { fxn(t, l, c) }\n" +
                        "    else { fxn(t, l) } \n"+
                        "}\n" +
                        "window.__CORTEXJS_TURNOFF__ = () => { HTMLElement.prototype.addEventListener = __CORTEXJS_add__ }\n"
        ));
    }

    private static ChromeOptions _initOptions(boolean headless) {
        ChromeOptions options = new ChromeOptions();
        if (headless) {
//            options.addArguments("--disable-gpu");
            options.addArguments("--headless");
            options.addArguments("--hide-scrollbars");
//            options.addArguments("--window-size=1920,1080");
//            options.addArguments("--ignore-certificate-errors");
        }
        options.addArguments("--disable-web-security");
        return options;
    }
//    File f = new File(ClassLoader.getSystemClassLoader().getResource("logback.xml").getFile());

    public Map<String, Object> send(String commandName, Map<String, Object> parameters) {
        Map<String, Object> command = new HashMap<>();
        command.put("cmd", commandName);
        command.put("params", parameters);
        try {
            Response response = execute("executeCdpCommand", command);
            return (Map<String, Object>) (response.getValue());
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            if (exceptionMsg.contains("\"message\":\"Invalid parameters\"")) {
                exceptionMsg = "invalid parameters for the command '"+commandName+"'. check command's docs.";
            }

            if (exceptionMsg.contains("\"message\":\"'"+commandName+"' wasn't found\"")) {
                exceptionMsg = "unknown command '"+commandName+"'.";
            }

            throw new WebDriverException(exceptionMsg);
        }
    }

    public Map<String, Object> send(String command) {
        return send(command, new HashMap<>());
    }

    public Map<String, Object> evaluate(String script) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("returnByValue", Boolean.TRUE);
        parameters.put("expression", script);
        return send("Runtime.evaluate", parameters);
    }

    public long documentHeight = 0;

    public void autoScroll() throws InterruptedException {
        long t0 = System.currentTimeMillis();
        List<Long> contentHeightPerIter = new ArrayList<>();
        List<Long> bottomPerIter = new ArrayList<>();
        while (System.currentTimeMillis()-t0<30000) {
            long top = (long)executeScript("return parseInt(Array.from(document.body.querySelectorAll('*')).filter(el=>Math.abs(el.getBoundingClientRect().width*el.getBoundingClientRect().height)>100).sort((a,b)=> -b.getBoundingClientRect().bottom/(b.getBoundingClientRect().height+1)+a.getBoundingClientRect().bottom/(a.getBoundingClientRect().height+1) )[0].getBoundingClientRect().top)");
            long bottom = (long)executeScript("return parseInt(Array.from(document.body.querySelectorAll('*')).filter(el=>Math.abs(el.getBoundingClientRect().width*el.getBoundingClientRect().height)>100).sort((a,b)=> b.getBoundingClientRect().bottom/(b.getBoundingClientRect().height+1)-a.getBoundingClientRect().bottom/(a.getBoundingClientRect().height+1) )[0].getBoundingClientRect().bottom)");
            long height = (bottom-top) + Math.abs(bottom);
            bottomPerIter.add(bottom);
            evaluate("Array.from(document.body.querySelectorAll('*')).filter(el=>Math.abs(el.getBoundingClientRect().width*el.getBoundingClientRect().height)>100).sort((a,b)=> b.getBoundingClientRect().bottom/(b.getBoundingClientRect().height+1)-a.getBoundingClientRect().bottom/(a.getBoundingClientRect().height+1) )[0].scrollIntoView({behavior: 'smooth', block: 'start'})");
            Thread.sleep(1000);
            contentHeightPerIter.add(height);
            if (contentHeightPerIter.size()>3) {
                int n = contentHeightPerIter.size();
                if (contentHeightPerIter.get(n-1).equals(contentHeightPerIter.get(n-2))
                 && contentHeightPerIter.get(n-2).equals(contentHeightPerIter.get(n-3))) {
                    this.documentHeight = Math.max(contentHeightPerIter.get(n-1), bottomPerIter.get(0));
                    break;
                }
            }
        }
        evaluate("Array.from(document.body.querySelectorAll('*')).filter(el=>Math.abs(el.getBoundingClientRect().width*el.getBoundingClientRect().height)>100).sort((a,b)=> a.getBoundingClientRect().bottom/(a.getBoundingClientRect().height+1)-b.getBoundingClientRect().bottom/(b.getBoundingClientRect().height+1) )[0].scrollIntoView({behavior: 'smooth', block: 'start'})");
        Thread.sleep(1000);
        evaluate("Array.from(document.body.querySelectorAll('*')).filter(el=>Math.abs(el.getBoundingClientRect().width*el.getBoundingClientRect().height)>100).sort((a,b)=> a.getBoundingClientRect().bottom/(a.getBoundingClientRect().height+1)-b.getBoundingClientRect().bottom/(b.getBoundingClientRect().height+1) )[0].scrollIntoView({behavior: 'smooth', block: 'start'})");
        Thread.sleep(1000);
    }

    public byte[] getScreenshot() throws InterruptedException {
        Map<String, Object> layout = send("Page.getLayoutMetrics");
        int fullWidth = ((Long)((Map<String, Object>)layout.get("contentSize")).get("width")).intValue();
        int fullHeight = ((Long)((Map<String, Object>)layout.get("contentSize")).get("height")).intValue();
        int windowWidth = ((Long)((Map<String, Object>)layout.get("visualViewport")).get("clientWidth")).intValue();
        int windowHeight = ((Long)((Map<String, Object>)layout.get("visualViewport")).get("clientHeight")).intValue();

        fullHeight = (int)Math.min(this.documentHeight, 10000); // internal screenshot buffer in some browsers is capped at 12000

        send("Emulation.setDeviceMetricsOverride",
                ImmutableMap.of("width", fullWidth, "height", fullHeight,
                        "deviceScaleFactor", Long.valueOf(1), "mobile", Boolean.FALSE,
                        "fitWindow", Boolean.FALSE)
        );
//        send("Emulation.setVisibleSize", ImmutableMap.of("width", fullWidth,
//                                                                        "height", fullHeight));

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fromSurface", true);

        Map<String, Object> rawB64Buffer = send("Page.captureScreenshot", parameters);
//        send("Emulation.setVisibleSize", ImmutableMap.of(
//                "x", Long.valueOf(0), "y", Long.valueOf(0),
//                "width", windowWidth, "height", windowHeight));
//        send("Emulation.clearDeviceMetricsOverride");
        return Base64.getDecoder().decode((String)(rawB64Buffer.get("data")));
    }

    public void goTo(String url) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("url", url);
        send("Page.navigate", parameters);
    }
}
