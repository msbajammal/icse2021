package org.icse2020.axeray;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Group {
    public Group() { }

    public Group(Group copy) {
        this.rootXPath = copy.rootXPath;
        this.bbox = new Rectangle(copy.bbox);
        this.ROIs = new ArrayList<>(copy.ROIs.size());
        for (int i=0; i<copy.ROIs.size(); i++) {
            this.ROIs.add(new ROI(copy.ROIs.get(i)));
        }
    }

    public boolean isEquivalentTo(Group anotherGroup) {
        boolean result=false; boolean isSet=false;
        if (ROIs.size() == anotherGroup.ROIs.size()) {
            for (int i=0; i<ROIs.size(); i++) {
                if (ROIs.contains(anotherGroup.ROIs.get(i))) {
                    continue;
                } else {
                    result = false; isSet = true;
                    break;
                }
            }
            if (!isSet) {
                result = true; isSet = true;
            }
        } else {
            result = false; isSet = true;
        }
        return result;
    }

    public int textCount() {
        int count=0;
        for (ROI R : ROIs) {
            if (R.type.contains("text")) count++;
        }
        return count;
    }

    public boolean matches(String... content) {
        for (String match : content) {
            boolean found = false;
            for (ROI R : ROIs) {
                if (R.content.contains(match)) {
                    found = true;
                    break;
                }
            }
            if (!found) return false;
        }
        return true;
    }

    public List<ROI> getIntersectionByROI(Group G) {
        List<ROI> intersection = new ArrayList<>(ROIs.size());
        for (ROI R : this.ROIs) {
            if (G.contains(R)) {
                intersection.add(R);
            }
        }
        return intersection;
    }

    public boolean contains(ROI R) {
        return ROIs.contains(R);
    }

    public boolean containsAll(List<ROI> ROIs) {
        return this.ROIs.containsAll(ROIs);
    }

    public boolean containsByDOM(ROI R) {
        return R.xpath.contains(rootXPath);
    }
    public String rootXPath;
    public List<ROI> ROIs;
    public List<Group> children = new ArrayList<>();
    public Group parent = null;
    public Rectangle bbox;
    public String role = "region";
    public int level = -1;
    public boolean containsCentroidOf(ROI R) {
        Point center = R.getCenter();
        return bbox.contains(center);
    }

    public boolean contains(Group G) {
        return G.isContainedBy(this);
    }

    public int getArea() {
        return bbox.height*bbox.width;
    }

    public Point getCenter() {
        return new Point((int)(bbox.getCenterX()), (int)(bbox.getCenterY()));
    }

    public double getDistance() {
        Point c = new Point(bbox.x, bbox.y);
        return c.distance(0,0);
    }

    public Rectangle getIntersectionRegionWith(Group G) {
        return G.bbox.intersection(this.bbox);
    }

    public boolean X(Rectangle R) { return this.bbox.intersects(R); }
    public boolean X(org.openqa.selenium.Rectangle R) {
        return this.bbox.intersects(new Rectangle(R.x, R.y, R.width, R.height));
    }


    public void shrinkToFitContent() {
        Rectangle bounds = GroupsProcessor.getContentBounds(this);
        this.bbox = new Rectangle(bounds);
    }

    public String getContent() {
        StringBuilder sb = new StringBuilder("");
        for (ROI R : this.ROIs) {
            if (R.type.equals("text") && !R.content.equals("")) {
                sb.append(R.content).append(" ");
            }
        }
        return sb.toString();
    }

    public String toString() {
        return "Group: "+this.getContent();
    }

    public int getClickablesCount() {
        int count=0;
        for (ROI R : this.ROIs) {
            if (R.isClickable) {
                count++;
            }
        }
        return count;
    }

    public boolean isContainedBy(Group G) {
        if (this.ROIs.size() <= G.ROIs.size()) {
            for (ROI R : this.ROIs) {
                if (G.intersectsWithROI(R)) { continue;
                } else { return false; }
            }
            return true;
        } else {
            return false;
        }
    }

    public Map<String, List<ROI>> getCrossings(List<ROI> globalROIs) {
        Map<String, List<ROI>> crossings = new HashMap<>(globalROIs.size());
        crossings.put("top", new ArrayList<>(globalROIs.size()));
        crossings.put("right", new ArrayList<>(globalROIs.size()));
        crossings.put("bottom", new ArrayList<>(globalROIs.size()));
        crossings.put("left", new ArrayList<>(globalROIs.size()));
        int x1 = bbox.x, x2 = bbox.x+bbox.width;
        int y1 = bbox.y, y2 = bbox.y+bbox.height;
        List<ROI> list;
        for (ROI R : globalROIs) {
            if (R.x1 < x1 && x1 < R.x2) {
                list = crossings.get("left");
                list.add(R);
                crossings.put("left", list);
            }

            if (R.x1 < x2 && x2 < R.x2) {
                list = crossings.get("right");
                list.add(R);
                crossings.put("right", list);
            }

            if (R.y1 < y1 && y1 < R.y2) {
                list = crossings.get("top");
                list.add(R);
                crossings.put("top", list);
            }

            if (R.y1 < y2 && y2 < R.y2) {
                list = crossings.get("bottom");
                list.add(R);
                crossings.put("bottom", list);
            }
        }
        return crossings;
    }

    public List<ROI> getROIsInside(Rectangle region) {
        List<ROI> result = new ArrayList<>(this.ROIs.size());
        for (ROI R : this.ROIs) {
            if (R.isInside(region)) result.add(R);
        }
        return result;
    }

    public boolean isStrictlyInside(Group G) {
        return G.bbox.contains(bbox);
    }

    public boolean intersectsWithROI(ROI R) {
        return bbox.intersects(new Rectangle(R.x1, R.y1, R.width, R.height));
    }

    @Override
    public int hashCode() {
        return this.rootXPath.hashCode();
    }

    @Override
    public boolean equals(Object g) {
        if (!(g instanceof Group)) {
            return false;
        } else {
            return this.rootXPath.equals(((Group)g).rootXPath);
        }
    }

}