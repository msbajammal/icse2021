package org.icse2020.axeray;

import de.vandermeer.asciitable.AsciiTable;

import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class GroupTree {
    public static List<Group> getRoots(List<Group> allGroups, List<ROI> ROIs) {
        return getRoots(allGroups, ROIs, false);
    }

    public static List<Group> getRoots(List<Group> allGroups, List<ROI> ROIs, boolean debug) {
        List<Group> groups;
//        Map<ROI, Group> mapROItoGroup;
//        Map<Group, List<ROI>> mapGroupToROIs;

        int netCount = GroupsProcessor.netEffectiveROITally(allGroups);
        groups = allGroups.stream()
                .filter(g -> g.ROIs.size()< netCount && g.ROIs.size()>5)
                .collect(Collectors.toList());
//        mapROItoGroup = new HashMap<>(ROIs.size());
//        mapGroupToROIs = new HashMap<>(groups.size());

        List<Group> matches = new ArrayList<>(groups.size());
        Set<Group> roots = new HashSet<>(groups.size());
        Comparator<Group> comparator = (Group a, Group b) -> b.getArea()-a.getArea();
        int noMatchCount = 0;
        int matchCount = 0;
        for (ROI R : ROIs) {
            for (Group G : groups) {
//                if (R.coveredBy(G.bbox)) {
                if (R.isCenteredInside(G.bbox)) {
                    matches.add(G);
                }
            }
            if (matches.size()>0) {
                matchCount++;
                Collections.sort(matches, comparator);
                roots.add(matches.get(0));
//                mapROItoGroup.put(R, matches.get(0));
//                if (!mapGroupToROIs.containsKey(matches.get(0))) {
//                    mapGroupToROIs.put(matches.get(0), new ArrayList<>(ROIs.size()));
//                }
//                List<ROI> placeholder = mapGroupToROIs.get(matches.get(0));
//                placeholder.add(R);
//                mapGroupToROIs.put(matches.get(0), placeholder);
            } else {
                noMatchCount++;
            }
            matches.clear();
        }

//            Group root = roots.stream().findFirst().get();
//            List<Group> rootSubgroups = new ArrayList<>(groups.size());
//            for (Group G : groups) {
//                if (root.contains(G)) {
//                    rootSubgroups.add(new Group(G));
//                }
//            }
//            return getRoots(rootSubgroups, root.ROIs);
            return GroupsProcessor.shrinkToFit(new ArrayList<>(roots));
//        }
    }


    public static void checkIntersections(List<Group> groups) {
        AsciiTable table = new AsciiTable();
        table.addRule();
        table.addRow("Idx 1", "Idx 2", "Intersect?");
        table.addRule();
        for (int i=0; i<groups.size(); i++) {
            for (int j=i+1; j<groups.size(); j++) {
                table.addRow(i, j, groups.get(i).getIntersectionByROI(groups.get(j)).size()>0);
            }
        }
        table.addRule();
        System.out.println(table.render());
    }

    public static List<Group> pruneByInteractivity(List<Group> groups) {
        List<Group> pruned = new ArrayList<>(groups);
        for (Group g : groups) {
            if (g.getClickablesCount()<=3) {
                pruned.remove(g);
            }
        }
        return pruned;
    }

    public static List<Group> pruneByContainment_2(List<Group> groups) {
        List<Group> prunedGroups = new ArrayList<>();
        for (Group possiblyRedundantGroup : groups) {
            List<Group> otherGroups = groups.stream()
                                                .filter(group -> group != possiblyRedundantGroup)
                                                .collect(Collectors.toList());
            Set<ROI> allROIsInOtherGroups = new HashSet<>();
            for (Group g : otherGroups) allROIsInOtherGroups.addAll(g.ROIs);

            for (ROI R : possiblyRedundantGroup.ROIs) {
                if ( ! allROIsInOtherGroups.contains(R)) { // R is unique to this group; so not redundant
                    prunedGroups.add(possiblyRedundantGroup);
                    break;
                }
            }
        }

        return prunedGroups;
    }

    public static List<Group> pruneByContainment(List<Group> groups) {
        List<Group> pruned = new ArrayList<>(groups);
        Map<Group, List<Group>> contains = new HashMap<>();
        Map<Group, List<Group>> containedBy = new HashMap<>();
        List<Group> list;
        for (Group i : groups) {
            for (Group j : groups) {
                if (!contains.containsKey(i)) contains.put(i, new ArrayList<>());
                if (!contains.containsKey(j)) contains.put(j, new ArrayList<>());
                if (!containedBy.containsKey(i)) containedBy.put(i, new ArrayList<>());
                if (!containedBy.containsKey(j)) containedBy.put(j, new ArrayList<>());

                if (i==j) continue;
                if (i.contains(j)) {
                    list = contains.get(i);
                    list.add(j);
                    contains.put(i, list);

                    list = containedBy.get(j);
                    list.add(i);
                    containedBy.put(j, list);
                }
            }
        }

        for (Group g : groups) {
            if (contains.get(g).size()==1 && containedBy.get(g).size()>1)
                pruned.remove(g);
        }

        return pruned;
    }

    public static void checkContainment(List<Group> groups) {
        AsciiTable table = new AsciiTable();
        table.addRule();
        table.addRow("Idx 1", "Idx 2", "1 contains 2?");
        table.addRule();
        for (int i=0; i<groups.size(); i++) {
            for (int j=0; j<groups.size(); j++) {
                table.addRow(i, j, groups.get(i).isContainedBy(groups.get(j)));
            }
        }
        table.addRule();
        System.out.println(table.render());
    }
}
