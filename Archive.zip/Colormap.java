package org.icse2020.axeray;
import javafx.scene.paint.Color;
import org.opencv.core.Scalar;

public class Colormap {
    private static final String[] KEYS = {
            "FFB300",
            "803E75",
            "FF6800",
            "A6BDD7",
            "C10020",
            "CEA262",
            "817066",

            "007D34",
            "F6768E",
            "00538A",
            "FF7A5C",
            "53377A",
            "FF8E00",
            "B32851",
            "F4C800",
            "7F180D",
            "93AA00",
            "593315",
            "F13A13",
            "232C16"
    };

    public static Scalar get(int index) {
        index = index % KEYS.length;
        Color color = Color.web("0x"+ KEYS[index]);
        int r = (int)(color.getRed()*255),
            g = (int)(color.getGreen()*255),
            b = (int)(color.getBlue()*255);
        return new Scalar(b,g,r);
    }

    public static String getHex(int index) {
        index = index % KEYS.length;
        return KEYS[index];
    }
}
