from sklearn.model_selection import train_test_split
import keras
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv2D, MaxPooling2D
from PIL import Image
import os
import numpy as np
from keras.metrics import categorical_accuracy
saved_models = './saved_models'
model_name = 'search_detector.h5'
pos_dir = './training/pos'
neg_dir = './training/neg'

posFiles = []
negFiles = []
files = []
x = []
y = []
negIndex = 0

for r,d,f in os.walk(pos_dir):
    for file in f:
        if '.DS_Store' not in file:
            filename = os.path.join(r, file)
            data = np.array(Image.open(filename))
            posFiles.append(filename)
            files.append(filename)
            x.append(data)
            y.append(1)

for r,d,f in os.walk(neg_dir):
    for file in f:
        if '.DS_Store' not in file:
            if negIndex == 0:
                negIndex = len(x)
            filename = os.path.join(r, file)
            data = np.array(Image.open(filename))
            negFiles.append(filename)
            files.append(filename)
            x.append(data)
            y.append(0)

x = np.array(x)
y = np.array(y)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25)
x_train = x_train.reshape(x_train.shape + (1,))
x_test = x_test.reshape(x_test.shape + (1,))
y_train = y_train.reshape(y_train.shape + (1,))
y_test = y_test.reshape(y_test.shape + (1,))

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
y_train = keras.utils.to_categorical(y_train, num_classes=2)
y_test = keras.utils.to_categorical(y_test, num_classes=2)

print("y_train")
print(y_train)


model = Sequential()
model.add(Conv2D(32, (3, 3), padding='same',
                 input_shape=x_train.shape[1:]))
model.add(Activation('relu'))
model.add(Conv2D(32, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Conv2D(64, (3, 3), padding='same'))
model.add(Activation('relu'))
model.add(Conv2D(64, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(512))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(2))
model.add(Activation('softmax'))

opt = keras.optimizers.RMSprop(learning_rate=0.0001, decay=1e-6)

model.compile(loss='categorical_crossentropy',
              optimizer=opt,
              metrics=['accuracy'])

def saveModel():
    if not os.path.isdir(saved_models):
        os.makedirs(saved_models)
    model_path = os.path.join(saved_models, model_name)
    model.save(model_path)
    scores = model.evaluate(x_test, y_test, verbose=1)

try:
    model.fit(x_train, y_train,
                batch_size=50,
                epochs=200,
                verbose=2,
                validation_data=(x_test, y_test),
                shuffle=True)
except KeyboardInterrupt:
    print("\nInterrupting ...")
    pass

saveModel()

for i in [7, 2, 4, 3, 9, 18, 5]:
    testPos = [x[i]]
    testPos = np.array(testPos)
    testPos = testPos.reshape(testPos.shape + (1,))
    print(files[i])
    print(model.predict(testPos))

    testNeg = [x[negIndex+i]]
    testNeg = np.array(testNeg)
    testNeg = testNeg.reshape(testNeg.shape + (1,))
    print(files[negIndex+i])
    print(model.predict(testNeg))
    print("\n")