1. Please open this folder in your favorite IDE to begin building.
2. The python scripts were used to build the search model (under 'saved_models'), 
   while the Java files were used to implement the approach. 
3. Please use the provided pom.xml for building with Maven.
4. Please double check version compatibility between your local browser 
   and your WebDriver for that browser.