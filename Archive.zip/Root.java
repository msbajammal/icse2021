package org.icse2020.axeray;

import org.opencv.core.Mat;
import org.openqa.selenium.JavascriptExecutor;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.List;

public class Root {

    public static String apply(Browser browser) throws Exception {
        browser.autoScroll();
        Mat screenshot = Util.readImageBuffer(browser.getScreenshot());
        List<ROI> ROIs = ROI.generateAll(browser);
        List<Group> groups = GroupsProcessor.extractGroups(browser, ROIs);
        List<Group> filt_a = GroupsProcessor.filterOutSingletons(groups, ROIs);
        List<Group> filt_b = GroupsProcessor.filterOutEquivalents(filt_a);
        List<Group> filt_c = GroupsProcessor.filterOutJointClickables(filt_b);
        List<Group> sum = GroupsProcessor.filterByContainment(filt_c, ROIs);
        List<Group> allMarked = Marker.getAll(screenshot, sum, ROIs, browser);
        Path tempFile = Files.createTempFile("", ".html");
        String location = tempFile.toString();
        File outputFile = new File(location);
        FileWriter writer = new FileWriter(outputFile, false);
        String report = Marker.generateInjectionReport(browser, allMarked);
        writer.write(report); writer.close();
        JavascriptExecutor js = (JavascriptExecutor) browser;
        js.executeScript("window.open();");
        List<String> tabs = new ArrayList<>(browser.getWindowHandles());
        browser.switchTo().window(tabs.get(tabs.size()-1));
        browser.get("file://" + location);
        return location;
    }

//  List<Group> h6 = tree.getLeafs();
//  Mat ROIImg = ROIExtractor.renderROIs(ROIs_step3);
//  Mat ROIImgPadded = new Mat(h1Img.size(), h1Img.type());
//  Core.copyMakeBorder(ROIImg, ROIImgPadded, 0, h1Img.cols()-ROIImg.cols(),
//                            0, h1Img.rows()-ROIImg.rows(), Core.BORDER_CONSTANT);
//  Mat disp = new Mat(h1Img.size(), h1Img.type());
//  Core.add(ROIImgPadded, h1Img, disp);
//  Util.displayMat(ROIExtractor.renderROIs(ROIs_step3), "Render", false);

//  List<Group> finalGroups = step4;
//  List<Group> finalGroups = GroupsProcessor.filterOutOverlaps(step4);

//  Util.displayMat(fullROIImage);
//  for (Group g : finalGroups) {
//       try {
//           GroupsProcessor.displayGroup(fullROI, g);
//       } catch (Exception e) {
//           System.out.println("--- Exception ---");
//           System.out.println("Group: " + g.bbox);
//           System.out.println("fullROI: "+ fullROI);
//           System.out.println("-----------------");
//       }
//   }

//   public static List<Rectangle> buildMap(Browser browser) throws IOException {
//        Cluster root = new Cluster(ROIExtractor.generateROIs(browser));
//        Object map = root.buildAdjacencyNeighborhood();
//        Map<String, Object> mapStats = root.getStats();
//        Map<String, List<Double>> mapGeomStats = root.getGeomStats();
//        List<Double> alignmentStats = root.getAlignmentStats();
//        Map<String, List<Double>> adjStats = root.getAdjacencyStats();
//
//        List<Double> data = adjStats.get("distances");
//        List<Double> y =  data;
//        Collections.sort(y);
//        List<Integer> x = IntStream.rangeClosed(1, y.size()).boxed().collect(Collectors.toList());
//        Histogram histDist = new Histogram(data, 100);
//        CategoryChart chart = new CategoryChartBuilder().width(800).height(600)
//                              .title("Adjacency").xAxisTitle("Delta_D").yAxisTitle("Frequency").build();
//        chart.addSeries("h", histDist.getxAxisData(), histDist.getyAxisData());
//        new SwingWrapper<CategoryChart>(chart).displayChart();
//        XYChart chart = new XYChartBuilder().width(800).height(600).build();
//        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Scatter);
//        chart.getStyler().setChartTitleVisible(false);
//        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
//        chart.getStyler().setMarkerSize(1);
//        chart.addSeries("a", x, y);
//        new SwingWrapper<XYChart>(chart).displayChart();
//        List<Cluster> clusters = root.findClusters();
//        Mat clusterDisplay = screenshot.clone();
//        List<Rectangle> result = new ArrayList<>(clusters.size());
//        for (Cluster C : clusters) {
//            clusterDisplay = C.renderOn(clusterDisplay);
//            result.add(C.getMBR(0));
//        }
//        Util.displayMat(clusterDisplay);
//        Imgcodecs.imwrite("cortex.png", clusterDisplay);
//        return result;
//    }

}
