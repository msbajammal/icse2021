package org.icse2020.axeray;

import java.awt.*;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import de.vandermeer.asciitable.AsciiTable;
import org.opencv.core.*;

import org.knowm.xchart.*;
import org.opencv.core.Point;
import org.opencv.imgproc.Imgproc;


public class GroupsProcessor {

    public static List<Group> filterOutJointClickables(List<Group> groups) {
        List<Group> filtered = new ArrayList<>(groups);
        for (Group a:groups) {
            for (Group b:groups) {
                if (a.equals(b)) continue;
                if (a.ROIs.stream().filter(x->x.isClickable).collect(Collectors.toList())
                        .containsAll(b.ROIs.stream().filter(x->x.isClickable).collect(Collectors.toList()))
                        && b.ROIs.stream().filter(x->x.isClickable).collect(Collectors.toList())
                        .containsAll(a.ROIs.stream().filter(x->x.isClickable).collect(Collectors.toList()))) {
                    if (a.ROIs.size()>b.ROIs.size()) {
                        filtered.remove(b);
                    } else {
                        filtered.remove(a);
                    }
                }
            }
        }
        return filtered;
    }

    public static int netEffectiveROITally(List<Group> groups) {
        List<ROI> ROIs = new ArrayList<>();
        for (Group g : groups) {
            for (ROI R : g.ROIs) {
                if ( ! ROIs.contains(R)) {
                    ROIs.add(R);
                }
            }
        }
        return ROIs.size();
    }

    public static List<Group> flatten(List<List<Group>> groups) {
        List<Group> flat = new ArrayList<>();
        for (List<Group> sublist : groups) {
            for (Group g : sublist) {
                flat.add(g);
            }
        }
        return flat;
    }

    public static List<Group> filterOutEquivalentsOriginal(List<Group> groups) {
        Set<Group> finalList = new HashSet<>(groups.size());
        List<Group> temp;

        for (Group group : groups) {
            temp = groups.stream()
                    .filter(g -> !g.isEquivalentTo(group))
                    .collect(Collectors.toList());
            finalList.addAll(temp);
        }
        return new ArrayList<>(finalList);
    }

    public static List<Group> findEquivalents(Group group, List<Group> allGroups) {
        List<Group> equivalents = new ArrayList<>(allGroups.size());
        for (Group g : allGroups) {
            if (g.isEquivalentTo(group) && g!=group) {
                equivalents.add(g);
            }
        }
        return equivalents;
    }


    public static List<Group> filterOutEquivalents(List<Group> groups) {
        List<Group> finalList = new ArrayList<>(groups);
        List<Group> removalList = new ArrayList<>();
        List<Group[]> equiSize = new ArrayList<>();
        List<Group[]> equivalents = new ArrayList<>();
        List<Group[]> nonEquivalents_A = new ArrayList<>();
        List<Group[]> nonEquivalents_B = new ArrayList<>();

        Group toBeRemoved; int counter=0;
        for (Group group : groups) {
            for (Group g : groups) {
                if (removalList.contains(g) || removalList.contains(group)) {
                    continue;
                }
                if (g.isEquivalentTo(group) && g != group) {
                    equivalents.add(new Group[]{group, g});
                    if (g.getArea() > group.getArea()) {
                        toBeRemoved = group;
                    } else if (g.getArea() < group.getArea()) {
                        toBeRemoved = g;
                    } else {
                        if (g.rootXPath.length()<group.rootXPath.length()) {
                            toBeRemoved = group;
                        } else {
                            toBeRemoved = g;
                        }
                    }
                    removalList.add(toBeRemoved);
                    finalList.remove(toBeRemoved);
                } else {
                    if (g.ROIs.size()==group.ROIs.size() && g!=group) {
                        nonEquivalents_A.add(new Group[]{group, g});
                    } else if (g.ROIs.size()!=group.ROIs.size() && g!=group) {
                        nonEquivalents_B.add(new Group[]{group, g});
                    }
                }
                if (g.ROIs.size()==group.ROIs.size() && g!=group) {
                    equiSize.add(new Group[]{group, g});
                }
            }
            counter++;
        }

        return finalList;
    }

    public static void compareGroups(Group g1, Group g2) {
        AsciiTable table = new AsciiTable();
        table.addRule();
        table.addRow("Group A", "Group B", "Identical?");
        table.addRule();
        String xpath1, xpath2;
        xpath1 = new String(g1.rootXPath).substring(g1.rootXPath.lastIndexOf("/html[1]/body[1]") + 16);
        xpath2 = new String(g2.rootXPath).substring(g2.rootXPath.lastIndexOf("/html[1]/body[1]") + 16);
        Boolean equal = false;
        equal = xpath1.equalsIgnoreCase(xpath2) ? true : false;
        table.addRow(xpath1, xpath2, equal ? "✓" : "");

        String box1 = "[" + g1.bbox.x + " - " + (g1.bbox.x + g1.bbox.width) + ", "
                          + g1.bbox.y + " - " + (g1.bbox.y + g1.bbox.height) + "]";
        String box2 = "[" + g2.bbox.x + " - " + (g2.bbox.x + g2.bbox.width) + ", "
                          + g2.bbox.y + " - " + (g2.bbox.y + g2.bbox.height) + "]";
        table.addRow(box1, box2, box1.equalsIgnoreCase(box2)?"✓":"");

        table.addRow("A = "+g1.getArea(), "A = "+g2.getArea(), g1.getArea()==g2.getArea()?"✓":"");

        if (g1.ROIs.size()!=g2.ROIs.size()) {
            if (g1.ROIs.size()<g2.ROIs.size()) {
                int i, j;
                for (i=0; i<g1.ROIs.size(); i++) {
                    equal = g1.ROIs.get(i)==g2.ROIs.get(i) ? true : false;
                    table.addRow(g1.ROIs.get(i), g2.ROIs.get(i), equal?"✓":"");
                }
                for (j=i; j<g2.ROIs.size(); j++) {
                    table.addRow("", g2.ROIs.get(j), "");
                }
            } else {
                int i, j;
                for (i=0; i<g2.ROIs.size(); i++) {
                    equal = g1.ROIs.get(i)==g2.ROIs.get(i) ? true : false;
                    table.addRow(g1.ROIs.get(i), g2.ROIs.get(i), equal?"✓":"");
                }
                for (j=i; j<g1.ROIs.size(); j++) {
                    table.addRow(g1.ROIs.get(j), "", "");
                }
            }
        } else {
            for (int i=0; i<g1.ROIs.size(); i++) {
                equal = g1.ROIs.get(i)==g2.ROIs.get(i) ? true : false;
                table.addRow(g1.ROIs.get(i), g2.ROIs.get(i), equal?"✓":"");
            }
        }
        table.addRule();
        System.out.println(table.render(100));
    }

//    public static List<Group> filterOutOverlaps(List<Group> groups) {
//        List<Group> finalList = new ArrayList<>(groups);
//        List<Group> temp = new ArrayList<>(groups.size());
//
//        for (Group group : groups) {
//            for (Group g : groups) {
//                if (group.bbox.contains(g.bbox) && g.getArea()<group.getArea()) {
////                    System.out.println("---------------------");
////                    System.out.println(group.bbox + "  " + group.rootXPath);
////                    System.out.println(g.bbox + "  " + g.rootXPath);
////                    System.out.println("---------------------");
//                    temp.add(g);
//                }
//            }
////            System.out.println("Before removal: " + finalList.size() + " groups.");
//            finalList.removeAll(temp);
////            System.out.println("After removal: " + finalList.size() + " groups.");
////            System.out.println("=============================");
//            temp.clear();
//        }
//        return finalList;
//    }

    public static List<Group> filterOutSingletons(List<Group> groups, List<ROI> ROIs) {
        List<Group> finalList = groups.stream()
                .filter(g -> g.ROIs.size()>2)
                .collect(Collectors.toList());

        return finalList;
    }

    public static List<Group> filterByContainment(List<Group> groups, List<ROI> ROIs) {
        List<Group> filtered = new ArrayList<>(groups.size());
        int count;
        for (Group G : groups) {
            count = 0;
            for (ROI R : ROIs) {
                if (G.containsByDOM(R)) count++;
            }
            if (count>0) filtered.add(G);
        }
        return filtered;
    }

    public static void displayGroup(Mat fullROIImage, Group g) throws IOException  {
        Mat groupImage = fullROIImage.submat(g.bbox.y,g.bbox.y+g.bbox.height,
                                         g.bbox.x, g.bbox.x+g.bbox.width);
        Util.displayMat(groupImage);
    }

    public static void displayGroupsPair(List<Group> groups, Group g1, Group g2) {
        int padding = 1;
        Rectangle bounds = getBounds(groups);
        int x0 = bounds.x, y0 = bounds.y;
        Mat image = new Mat(bounds.height+(padding*2), bounds.width+(padding*2), CvType.CV_8UC3);
        Rectangle r1 = new Rectangle(g1.bbox); r1.x = r1.x-x0+padding; r1.y = r1.y-y0+padding;
        Rectangle r2 = new Rectangle(g2.bbox); r2.x = r2.x-x0+padding; r2.y = r2.y-y0+padding;
        image = Util.drawRect(image, r1, -1);
        image = Util.drawRect(image, r2, -1);
        Util.displayMat(image, "Pair overlap", true);
    }

    public static Mat renderGroups(List<Group> groups, Mat screen) {
        Mat image = new Mat(screen.size(), CvType.CV_8UC3);
        for (Group g : groups) {
            image = Util.drawRect(image, g.bbox, 1);
        }
        return image;
    }

    public static Mat overlayGroups(Map<Group, String> roles, Mat screenshot) {
        List<Group> groups = new ArrayList<>(roles.size());
        List<String> labels = new ArrayList<>(roles.size());
        for (Group g : roles.keySet()) {
            groups.add(g);
            labels.add(roles.get(g));
        }
        return overlayGroups(groups, labels, screenshot);
    }

    public static Mat overlayGroups(List<Group> groups, List<String> labels, Mat screenshot) {
        Mat image = new Mat(screenshot.size(), screenshot.type());
        int labelX, labelY;
        Rectangle box;
        for (int i=0; i<groups.size(); i++) {
            box = groups.get(i).bbox;
            Imgproc.rectangle(image, new Point(box.x, box.y), new Point(box.x+box.width, box.y+box.height),
                    Colormap.get(i), -1);
        }
        image = Util.overlay(image, 0.7, screenshot, 0.3);

        for (int i=0; i<groups.size(); i++) {
            box = groups.get(i).bbox;
            labelX = box.x + 10;
            labelY = box.y + 20;
            Imgproc.rectangle(image, new Point(box.x+1, box.y+1), new Point(box.x+box.width-2, box.y+box.height-2),
                    new Scalar(0,0,0, 255), 2);
            Imgproc.putText(image, labels.get(i), new Point(labelX-1,labelY), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
            Imgproc.putText(image, labels.get(i), new Point(labelX+1,labelY), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
            Imgproc.putText(image, labels.get(i), new Point(labelX,labelY-1), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
            Imgproc.putText(image, labels.get(i), new Point(labelX,labelY+1), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
            Imgproc.putText(image, labels.get(i), new Point(labelX,labelY), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,0,0, 255),1);

        }
        return image;
    }

    public static Mat renderGroupsDirect(List<Group> groups, String title) {
        Rectangle bounds = getBounds(groups);
        Mat image = new Mat(bounds.height, bounds.width, CvType.CV_8UC3);
        for (Group g : groups) {
            image = Util.drawRect(image, g.bbox, 1);
        }
        return image;
    }


    public static List<Group> extractGroups(Browser browser, List<ROI> ROIs) throws Exception {
        List<Group> result = new ArrayList<>();
        List<Map<String, Object>> groups = (List<Map<String, Object>>)(browser.executeScript(
                "return window.__CORTEXJS.extractAllGroups();"));
        groups.forEach(group -> {
            String groupRootXPath = (String)(group.get("rootXPath"));
            int left, right, top, bottom;
            try {
                left = ((Double) (group.get("left"))).intValue();
            } catch (ClassCastException e) {
                left = ((Long) (group.get("left"))).intValue();
            }
            try {
                right = ((Double) (group.get("right"))).intValue();
            } catch (ClassCastException e) {
                right = ((Long) (group.get("right"))).intValue();
            }
            try {
                top = ((Double) (group.get("top"))).intValue();
            } catch (ClassCastException e) {
                top = ((Long) (group.get("top"))).intValue();
            }
            try {
                bottom = ((Double) (group.get("bottom"))).intValue();
            } catch (ClassCastException e) {
                bottom = ((Long) (group.get("bottom"))).intValue();
            }
            Rectangle groupBox = new Rectangle(left, top, right-left, bottom-top);
            List<ROI> groupROIs = new ArrayList<>(ROIs.size());
            ROIs.forEach(ROI -> {
                if (ROI.isChildOf(groupRootXPath) && ROI.getArea()>=100) {
                    groupROIs.add(ROI);
                }
            });

            Group g = new Group();
            g.rootXPath = groupRootXPath;
            g.bbox = new Rectangle(groupBox);
            g.ROIs = new ArrayList<>(groupROIs);
            result.add(g);
        });
        return result;
    }



    public static void displayGroups(List<Group> groups, Mat screen, String title) {
        Util.displayMat(renderGroups(groups, screen), title, false);
    }



        public static void plotAreas(List<Group> groups) {
        List<Integer> x = IntStream.rangeClosed(1, groups.size()).boxed().collect(Collectors.toList());
        List<Integer> y = new ArrayList<>(groups.size());
        for (Group g : groups) {
            y.add(g.getArea());
        }
        XYChart chart = new XYChartBuilder().width(800).height(600).build();
        chart.addSeries("s", x, y);
        chart.getStyler().setLegendVisible(false);
        SwingWrapper<XYChart> swingWrapper = new SwingWrapper<>(chart);
        swingWrapper.displayChart().getRootPane().paintImmediately(0,0,800,600);
    }

    public static List<Group> shrinkToFit(List<Group> groups) {
        List<Group> result = new ArrayList<>(groups.size());
        Group x;
        for (Group g : groups) {
            x = new Group(g);
            x.shrinkToFitContent();
            result.add(x);
        }
        return result;
    }

    public static Rectangle getBounds(List<Group> groups) {
        int left=1000000000, top=1000000000, right=0, bottom=0;
        for (Group g : groups) {
            if (g.bbox.x < left) left = g.bbox.x;
            if (g.bbox.y < top) top = g.bbox.y;
            if (g.bbox.x+g.bbox.width > right) right = g.bbox.x+g.bbox.width;
            if (g.bbox.y+g.bbox.height > bottom) bottom = g.bbox.y+g.bbox.height;
        }
        return new Rectangle(left, top, right-left, bottom-top);
    }

    //    public static List<List<Group>> extractGroups(Browser browser, List<ROI> ROIs) throws IOException {
//        List<List<Group>> groups = new ArrayList<>();
//        Queue<String> roots = new ArrayDeque<>();
//        roots.add("/html/body");
//        traverseGroups(browser, ROIs, roots, groups);
//        return groups;
//    }
//
//    private static void traverseGroups(Browser browser, List<ROI> ROIs, Queue<String> rootsXPaths, List<List<Group>> groups) {
//        if (rootsXPaths.isEmpty()) {
//            return;
//        }
//
//        String XPath = rootsXPaths.poll();
//        List<Group> groupList = extractGroupsAt(browser, ROIs, XPath);
//        if (!groupList.isEmpty()) {
//            groups.add(groupList);
//            groupList.forEach(group -> {
//                rootsXPaths.add(group.rootXPath);
//            });
//        }
//
//        traverseGroups(browser, ROIs, rootsXPaths, groups);
//    }
//
//
//    private static List<Group> extractGroupsAt(Browser browser, List<ROI> ROIs, String rootXPath) {
//        List<Group> groups = new ArrayList<>();
//
//        List<Map<String, Object>> groupsMap = (List<Map<String, Object>>)(browser.executeScript(
//                                "return window.__CORTEXJS.findGroupRootsAt('"+rootXPath+"');"));
//        if (groupsMap != null) {
//            groupsMap.forEach(group -> {
//                if (group.containsKey("rootXPath")) {
//                    String groupRootXPath = (String)(group.get("rootXPath"));
//                    int left, right, top, bottom;
//                    try {
//                        left = ((Double) (group.get("left"))).intValue();
//                    } catch (ClassCastException e) {
//                        left = ((Long) (group.get("left"))).intValue();
//                    }
//                    try {
//                        right = ((Double) (group.get("right"))).intValue();
//                    } catch (ClassCastException e) {
//                        right = ((Long) (group.get("right"))).intValue();
//                    }
//                    try {
//                        top = ((Double) (group.get("top"))).intValue();
//                    } catch (ClassCastException e) {
//                        top = ((Long) (group.get("top"))).intValue();
//                    }
//                    try {
//                        bottom = ((Double) (group.get("bottom"))).intValue();
//                    } catch (ClassCastException e) {
//                        bottom = ((Long) (group.get("bottom"))).intValue();
//                    }
//                    Rectangle groupBox = new Rectangle(left, top, right-left, bottom-top);
//
//                    List<ROI> groupROIs = new ArrayList<>(ROIs.size());
//                    ROIs.forEach(ROI -> {
////                        if (ROI.isInside(groupBox)) {
//                        if (ROI.isCenteredInside(groupBox) && ROI.getArea()>=100) {
//                            groupROIs.add(ROI);
//                        }
//                    });
//
//                    Group g = new Group();
////                    g.parentXPath = rootXPath;
//                    g.rootXPath = groupRootXPath;
//                    g.bbox = new Rectangle(groupBox);
//                    g.ROIs = new ArrayList<>(groupROIs);
//                    groups.add(g);
//                }
//            });
//        }
//
//        return groups;
//    }

    public static Rectangle getContentBounds(Group g) {
        int left=1000000000, top=1000000000, right=0, bottom=0;
        for (ROI R : g.ROIs) {
            if (R.x1 < left) left = R.x1;
            if (R.y1 < top) top = R.y1;
            if (R.x1+R.width > right) right = R.x1 + R.width;
            if (R.y1+R.height > bottom) bottom = R.y1 + R.height;
        }
        return new Rectangle(left, top, right-left, bottom-top);
    }


    public static List<Group> trimToScreen(List<Group> groups, Mat screen) {
        List<Group> trimmed = new ArrayList<>(groups.size());
        int x, y, width, height, x1, x2, y1, y2;
        Group GG;
        for (Group G : groups) {
            x1 = Math.max(G.bbox.x, 0);
            y1 = Math.max(G.bbox.y, 0);
            x2 = Math.max(G.bbox.x+G.bbox.width, 0);
            y2 = Math.max(G.bbox.y+G.bbox.height, 0);

            x1 = Math.min(x1, screen.cols());
            y1 = Math.min(y1, screen.rows());
            x2 = Math.min(x2, screen.cols());
            y2 = Math.min(y2, screen.rows());

            GG = new Group(G);
            GG.bbox = new Rectangle(x1, y1, x2-x1, y2-y1);
            trimmed.add(GG);
//            x = Math.max(G.bbox.x, 0);
//            y = Math.max(G.bbox.y, 0);
//            if (x + G.bbox.width > screen.cols()) {
//                width = screen.cols()-x;
//            } else {
//                width = G.bbox.width;
//            }
//            if (y + G.bbox.height > screen.rows()) {
//                height = screen.rows()-y;
//            } else {
//                height = G.bbox.height;
//            }
//
//            GG = new Group(G);
//            GG.bbox.x = x; GG.bbox.y = y;
//            GG.bbox.width = width; GG.bbox.height = height;
//            trimmed.add(GG);
        }
        return trimmed;
    }


}
