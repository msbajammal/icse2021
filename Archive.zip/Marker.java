package org.icse2020.axeray;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

import edu.stanford.nlp.simple.Sentence;
import org.datavec.image.loader.NativeImageLoader;
import org.locationtech.jts.geom.*;
import org.locationtech.jts.index.strtree.STRtree;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.opencv.core.*;
import org.deeplearning4j.nn.modelimport.keras.KerasModelImport;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.nd4j.linalg.io.ClassPathResource;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;

public class Marker {

    public static double getContentVariance(Group g) {
        String content=g.getContent();
        Sentence sen;
        try {
            sen = new Sentence(content);
        } catch (IllegalStateException e) {
            sen = new Sentence("Bootstrap.");
        }
        List<String> POSList = sen.posTags();
        Map<String, Integer> counter = new HashMap<>();
        int c; int maxCount=0; String maxTag="";
        for (String tag : POSList) {
            if (!counter.containsKey(tag)) counter.put(tag, 0);
            c = counter.get(tag)+1;
            counter.put(tag, c);
            if (c>maxCount) {
                maxCount = c; maxTag = tag;
            }
        }
        int matchCount=0, mismatchCount=0;
        for (String tag : POSList) {
            if (tag.equalsIgnoreCase(maxTag)) {
                matchCount++;
            } else {
                mismatchCount++;
            }
        }
        return 1.0*mismatchCount/(matchCount+mismatchCount);
    }

    public static Group getMain(List<Group> allGroups, List<ROI> _allROIs) {
        List<Group> groups = new ArrayList<>(allGroups);
        List<Group> skipList = new ArrayList<>();
        Set<ROI> allROIsSet = new HashSet<>();
        for (Group g : groups) allROIsSet.addAll(g.ROIs);
        List<ROI> allROIs = new ArrayList<>(allROIsSet);
        for (Group g : groups) if (g.containsAll(allROIs)) skipList.add(g);
        groups.removeAll(skipList);

        Comparator<Group> cmp = (Group a, Group b) -> (int)(- a.getArea()*getContentVariance(a)
                + b.getArea()*getContentVariance(b));
        Collections.sort(groups, cmp);
        if (groups.size()>0) {
            Group result = groups.get(0);
            result.role = "main";
            return result;
        } else {
            return null;
        }
    }

    public static double getClickablesRatio(Group g) {
        int clickables=0, nonClickables=0;
        for (ROI R : g.ROIs) {
            if (R.isClickable) {
                clickables++;
            } else {
                nonClickables++;
            }
        }
        return 1.0*clickables/(clickables+nonClickables);
    }

    public static boolean _isAClickableGroup__2(Group g) {
        List<ROI> clickables = new ArrayList<>(), nonClickables = new ArrayList<>();
        Map<String, List<ROI>> hrefGroups = new HashMap<>();
        for (ROI R : g.ROIs) {
            String href = R.href;
            if (!href.equals("")) {
                if (!hrefGroups.containsKey(href)) {
                    hrefGroups.put(href, new ArrayList<>());
                }
                List<ROI> group = hrefGroups.get(href);
                group.add(R);
                hrefGroups.put(href, group);
            }
            if (R.isClickable && !R.type.toLowerCase().contains("input")) {
                if (R.type.equals("text") && R.content.matches("^(?s)[\\s\\n]*[a-zA-Z]+.*")) {
                    clickables.add(R);
                }
                if (R.type.equals("image")) {
                    clickables.add(R);
                }
            } else {
                nonClickables.add(R);
            }
        }

        if (hrefGroups.keySet().size()<=2) {
            return false;
        }

        return (1.0*clickables.size()/(clickables.size()+nonClickables.size()))>0.75;
    }

    public static boolean _hasUniformContent(Group g) {
        List<Integer> contentSizes = new ArrayList<>();
        for (ROI R : g.ROIs) {
            if (R.type.equals("text")) {
                contentSizes.add(R.content.replaceAll("\\s","").length());
            }
        }
        return (Collections.max(contentSizes)-Collections.min(contentSizes))<=5*Collections.min(contentSizes);

//        String content=g.getContent();
//        Sentence sen;
//        try {
//            sen = new Sentence(content);
//        } catch (IllegalStateException e) {
//            sen = new Sentence("Test ");
//        }
//        List<String> POSList = sen.posTags();
//        Map<String, Integer> counter = new HashMap<>();
//        int c; int maxCount=0; String maxTag="";
//        int symCount=0;
//        for (String tag : POSList) {
//            if (!counter.containsKey(tag)) counter.put(tag, 0);
//            c = counter.get(tag)+1;
//            counter.put(tag, c);
//            if (c>maxCount) {
//                maxCount = c; maxTag = tag;
//            }
//            if (tag.equals("SYM") || tag.equals("CD") || tag.equals("SENT")) {
//                symCount++;
//                if (symCount>=2) return false;
//            }
//        }
//        int matchCount=0, mismatchCount=0;
//        for (String tag : POSList) {
//            if (tag.equalsIgnoreCase(maxTag)) {
//                matchCount++;
//            } else {
//                mismatchCount++;
//            }
//        }
//   return content.length()*1.0*mismatchCount/(matchCount+mismatchCount);
    }

    public static boolean _isAClickableGroup(Group g) {
        List<ROI> clickables = new ArrayList<>(), nonClickables = new ArrayList<>();
        List<String> hrefs = new ArrayList<>();
        for (ROI R : g.ROIs) {
            if (R.isClickable && !R.type.toLowerCase().contains("input")) {
                if (R.type.equals("text") && R.content.matches("^(?s)[\\s\\n]*[a-zA-Z]+.*")) {
                    if (!R.href.equals("")) hrefs.add(R.href);
                    clickables.add(R);
                }
                if (R.type.equals("image")) {
                    if (!R.href.equals("")) hrefs.add(R.href);
                    clickables.add(R);
                }
            } else {
                nonClickables.add(R);
            }
        }
        Set<String> _hrefs = new HashSet<>(hrefs);
//        if (_hrefs.size() < hrefs.size()) {
//            return false;
//        } else {
            return (1.0*clickables.size()/(clickables.size()+nonClickables.size()))>0.75;
//        }
    }

    public static String generateOutput(Browser browser, List<Group> inferred) {
        StringBuilder report = new StringBuilder();
        List<WebElement> main = browser.findElementsByCssSelector ("*[role='main'],main");
        List<WebElement> nav = browser.findElementsByCssSelector ("*[role='navigation'],nav");
        List<WebElement> search = browser.findElementsByCssSelector ("*[role='search']");
        List<WebElement> footer = browser.findElementsByCssSelector ("*[role='contentinfo'],footer");
        List<WebElement> landmarks = new ArrayList<>();
        landmarks.addAll(main); landmarks.addAll(nav); landmarks.addAll(search); landmarks.addAll(footer);
        java.awt.Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        report.append("<html><head><title>Test Report</title><link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>" +
                "<style>.highlight { padding: 5px; border: 3px dashed black; } .desc {background-color:white; font-size:18px;} code {font-size: 17px; } </style></head><body>");

        List<Group> infNav = inferred.stream().filter(g->g.role.equals("nav")).collect(Collectors.toList());
        Map<Group, List<Group>> xContains = new HashMap<>();
        Map<Group, List<Group>> xContainedBy = new HashMap<>();
        List<Group> footNavs = new ArrayList<>();
        List<Group> infFoot = inferred.stream().filter(g->g.role.equals("footer")).collect(Collectors.toList());
        for (Group a:infNav) {
            List<Group> contains = new ArrayList<>();
            List<Group> containedBy = new ArrayList<>();
            for (Group b:infNav) {
                if (a.equals(b)) continue;
                if (a.contains(b)) contains.add(b);
                if (a.isContainedBy(b)) containedBy.add(b);
            }
            xContains.put(a, contains);
            xContainedBy.put(a, containedBy);
            if (infFoot.size()>0&&infFoot.get(0).contains(a)) footNavs.add(a);
        }
        for (Group a:infNav) {
            if (xContains.get(a).size()==1) inferred.remove(xContains.get(a).get(0));
            if (xContains.get(a).size()>1) inferred.remove(a);
//            if (footNavs.contains(a)) inferred.remove(a);
        }

        for (Group g : inferred) {
            if (g==null||g.getArea()<=0) continue;
            WebElement e = browser.findElementByXPath(g.rootXPath);
            String b64 = e.getScreenshotAs(OutputType.BASE64);
            byte[] raw = Base64.getDecoder().decode((String)(b64));
            Mat temp = Imgcodecs.imdecode(new MatOfByte(raw), Imgcodecs.IMREAD_UNCHANGED);
            Mat mat = new Mat();
            if (temp.cols()>0.7*dim.width) {
                double scale = temp.cols()/(0.7*dim.width);
                Imgproc.resize(temp, mat, new Size(Math.round(0.7*dim.width),Math.round(temp.rows()/scale)), 0, 0, Imgproc.INTER_AREA );
            } else {
                mat = temp;
            }
            report.append("<br />&nbsp;<hr /><br />&nbsp;<br />&nbsp;<br /><blockquote>");
            if (g.role.equals("nav")) report.append("<span class='desc'>The tool has inferred that the following appears to be a <b>navigation</b> region:</span>");
            if (g.role.equals("footer")) report.append("<span class='desc'>The tool has inferred that the following appears to be the <b>footer</b> of the page:</span>");
            if (g.role.equals("search")) report.append("<span class='desc'>The tool has inferred that the following appears to be a <b>search</b> region:</span>");
            if (g.role.equals("main")) report.append("<span class='desc'>The tool has inferred that the following region appears to be the <b>main</b> region of the page:</span>");
            report.append("<br />");

            if (mat.rows()>0.5*dim.height) {
                report.append(g.rootXPath);
            } else {
                MatOfByte buf = new MatOfByte();
                Imgcodecs.imencode(".png", mat, buf);
                byte[] arr = buf.toArray();
                String matb64 = Base64.getEncoder().encodeToString(arr);
                report.append("<img class='highlight' src='data:image/png;base64,"+matb64+"' />\n");
            }

            boolean muPresent = false; String markup="";
            for (WebElement l : landmarks) {
                if (g.role.equals("main")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("main")||l.getTagName().equalsIgnoreCase("main"))&&g.X(l.getRect())) { muPresent = true; break; }
                if (g.role.equals("nav")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("navigation")||l.getTagName().equalsIgnoreCase("nav"))&&g.X(l.getRect())) { muPresent = true; break; }
                if (g.role.equals("search")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("search"))&&g.X(l.getRect())) { muPresent = true; break; }
                if (g.role.equals("footer")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("contentinfo")||l.getTagName().equalsIgnoreCase("footer"))&&g.X(l.getRect())) { muPresent = true; break; }
            }

            if (g.role.equals("main")) markup = "<code>&lt;... role='main'&gt;</code> or <code>&lt;main&gt;</code>";
            if (g.role.equals("nav")) markup = "<code>&lt;... role='navigation'&gt;</code> or <code>&lt;nav&gt;</code>";
            if (g.role.equals("search")) markup = "<code>&lt;... role='search'&gt;</code>";
            if (g.role.equals("footer")) markup = "<code>&lt;... role='contentinfo'&gt;</code> or <code>&lt;footer&gt;</code>";


            report.append("&nbsp;<br />");
            if (muPresent) {
                report.append("<span class='desc' style='color:green;'><i class='fa fa-check-square'></i> The page's HTML correctly marks up this region using the appropriate semantics: "+markup+"</span>");
            } else {
                report.append("<span class='desc' style='color:red;'><i class='fa fa-window-close'></i> However, the page's HTML does not markup this region using the appropriate semantics: "+markup+" </span>");
            }
            report.append("&nbsp;<br />&nbsp;<br />");

            report.append("</blockquote>");

        }
        report.append("<br />&nbsp;<br /></body></html>");

        return report.toString();
    }

    public static String generateInjectionReport(Browser browser, List<Group> inferred) {
        StringBuilder report = new StringBuilder();
        List<WebElement> main = browser.findElementsByCssSelector ("*[role='main'],main");
        List<WebElement> nav = browser.findElementsByCssSelector ("*[role='navigation'],nav");
        List<WebElement> search = browser.findElementsByCssSelector ("*[role='search']");
        List<WebElement> footer = browser.findElementsByCssSelector ("*[role='contentinfo'],footer");
        List<WebElement> landmarks = new ArrayList<>();
        landmarks.addAll(main); landmarks.addAll(nav); landmarks.addAll(search); landmarks.addAll(footer);
        java.awt.Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        report.append("<html><head><title>Test Report</title><link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>" +
                "<style>.highlight { padding: 5px; border: 3px dashed black; } .desc {background-color:white; font-size:18px;} code {font-size: 17px; } </style></head><body>");

        if (landmarks.size()>0) {
            report.append("<br/><br/><blockquote>These are the semantic landmarks declared in the page's HTML markup:<br />&nbsp;<br />");

            for (WebElement l : landmarks) {
                String repr = "<"+l.getTagName()+ "";
                if (l.getAttribute("role")!=null) { repr+=" role='"+l.getAttribute("role")+"' ...>"; }
                else { repr+=" ...>";}

                if (l.getSize().height*l.getSize().width==0) {
//                    System.out.println("Zero area built-in landmark: " + repr);
                    continue;
                }

                if (main.contains(l)) report.append("<br /><br />The main region: ");
                if (nav.contains(l)) report.append("<br /><br />Navigation region: ");
                if (search.contains(l)) report.append("<br /><br />Search region: ");
                if (footer.contains(l)) report.append("<br /><br />The footer region: ");


                String b64 = l.getScreenshotAs(OutputType.BASE64);
                byte[] raw = Base64.getDecoder().decode((String)(b64));
                Mat temp = Imgcodecs.imdecode(new MatOfByte(raw), Imgcodecs.IMREAD_UNCHANGED);
                Mat mat = new Mat();

                report.append("<code>"+repr.replace("<","&lt;").replace(">","&gt;")+"</code><br/>");

                if (temp.cols()>0.7*dim.width) {
                    double scale = temp.cols()/(0.7*dim.width);
                    Imgproc.resize(temp, mat, new Size(Math.round(0.7*dim.width),Math.round(temp.rows()/scale)), 0, 0, Imgproc.INTER_AREA );
                } else {
                    mat = temp;
                }

                if (mat.rows()>0.5*dim.height) {
                    report.append(Util.XPath(l));
                } else {
                    MatOfByte buf = new MatOfByte();
                    Imgcodecs.imencode(".png", mat, buf);
                    byte[] arr = buf.toArray();
                    String matb64 = Base64.getEncoder().encodeToString(arr);
                    report.append("<img class='highlight' src='data:image/png;base64,"+matb64+"' />\n");
                }
            }
            report.append("</blockquote>");
        } else {
            report.append("<center><br/><br/><span class='desc'>The page's markup <b>did not</b> declare any semantic landmarks.</span></center><br/><br/>");
        }
        report.append("<br/><br/><br/>All "+landmarks.size()+" landmarks have been cleared for fault injection ...<div style='height:50px'>&nbsp;</div><br/><br/><br/>");
        landmarks.clear();
//        report.append("<br/><br/><br/><div style='height:50px'>&nbsp;</div><br/><br/><br/>");
        List<Group> infNav = inferred.stream().filter(g->g.role.equals("nav")).collect(Collectors.toList());
        Map<Group, List<Group>> xContains = new HashMap<>();
        Map<Group, List<Group>> xContainedBy = new HashMap<>();
        List<Group> footNavs = new ArrayList<>();
        List<Group> infFoot = inferred.stream().filter(g->g.role.equals("footer")).collect(Collectors.toList());
        for (Group a:infNav) {
            List<Group> contains = new ArrayList<>();
            List<Group> containedBy = new ArrayList<>();
            for (Group b:infNav) {
                if (a.equals(b)) continue;
                if (a.contains(b)) contains.add(b);
                if (a.isContainedBy(b)) containedBy.add(b);
            }
            xContains.put(a, contains);
            xContainedBy.put(a, containedBy);
            if (infFoot.size()>0&&infFoot.get(0).contains(a)) footNavs.add(a);
        }
        for (Group a:infNav) {
            if (xContains.get(a).size()==1) inferred.remove(xContains.get(a).get(0));
            if (xContains.get(a).size()>1) inferred.remove(a);
//            if (footNavs.contains(a)) inferred.remove(a);
        }

        for (Group g : inferred) {
            if (g==null||g.getArea()<=0) continue;
            WebElement e = browser.findElementByXPath(g.rootXPath);
            String b64 = e.getScreenshotAs(OutputType.BASE64);
            byte[] raw = Base64.getDecoder().decode((String)(b64));
            Mat temp = Imgcodecs.imdecode(new MatOfByte(raw), Imgcodecs.IMREAD_UNCHANGED);
            Mat mat = new Mat();
            if (temp.cols()>0.7*dim.width) {
                double scale = temp.cols()/(0.7*dim.width);
                Imgproc.resize(temp, mat, new Size(Math.round(0.7*dim.width),Math.round(temp.rows()/scale)), 0, 0, Imgproc.INTER_AREA );
            } else {
                mat = temp;
            }
            report.append("<br />&nbsp;<hr /><br />&nbsp;<br />&nbsp;<br /><blockquote>");
            if (g.role.equals("nav")) report.append("<span class='desc'>The tool has inferred that the following appears to be a <b>navigation</b> region:</span>");
            if (g.role.equals("footer")) report.append("<span class='desc'>The tool has inferred that the following appears to be the <b>footer</b> of the page:</span>");
            if (g.role.equals("search")) report.append("<span class='desc'>The tool has inferred that the following appears to be a <b>search</b> region:</span>");
            if (g.role.equals("main")) report.append("<span class='desc'>The tool has inferred that the following region appears to be the <b>main</b> region of the page:</span>");
            report.append("<br />");

            if (mat.rows()>dim.height) {
                report.append(g.rootXPath);
            } else {
                MatOfByte buf = new MatOfByte();
                Imgcodecs.imencode(".png", mat, buf);
                byte[] arr = buf.toArray();
                String matb64 = Base64.getEncoder().encodeToString(arr);
                report.append("<img class='highlight' src='data:image/png;base64,"+matb64+"' />\n");
            }

            boolean muPresent = false; String markup="";
            for (WebElement l : landmarks) {
                if (g.role.equals("main")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("main")||l.getTagName().equalsIgnoreCase("main"))&&g.X(l.getRect())) { muPresent = true; break; }
                if (g.role.equals("nav")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("navigation")||l.getTagName().equalsIgnoreCase("nav"))&&g.X(l.getRect())) { muPresent = true; break; }
                if (g.role.equals("search")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("search"))&&g.X(l.getRect())) { muPresent = true; break; }
                if (g.role.equals("footer")&&(l.getAttribute("role")!=null&&l.getAttribute("role").equalsIgnoreCase("contentinfo")||l.getTagName().equalsIgnoreCase("footer"))&&g.X(l.getRect())) { muPresent = true; break; }
            }

            if (g.role.equals("main")) markup = "<code>&lt;... role='main'&gt;</code> or <code>&lt;main&gt;</code>";
            if (g.role.equals("nav")) markup = "<code>&lt;... role='navigation'&gt;</code> or <code>&lt;nav&gt;</code>";
            if (g.role.equals("search")) markup = "<code>&lt;... role='search'&gt;</code>";
            if (g.role.equals("footer")) markup = "<code>&lt;... role='contentinfo'&gt;</code> or <code>&lt;footer&gt;</code>";

            report.append("&nbsp;<br />");
            if (muPresent) {
                report.append("<span class='desc' style='color:green;'><i class='fa fa-check-square'></i> The page's HTML correctly marks up this region using the appropriate semantics: "+markup+"</span>");
            } else {
                report.append("<span class='desc' style='color:red;'><i class='fa fa-window-close'></i> However, the page's HTML does not markup this region using the appropriate semantics: "+markup+" </span>");
            }
            report.append("&nbsp;<br />&nbsp;<br />");
            report.append("</blockquote>");

        }
        report.append("<br />&nbsp;<br /></body></html>");
        return report.toString();
    }

    public static List<Group> getNav(List<Group> groups) {
        List<Group> result = new ArrayList<>(groups.size());
        groupsLoop: for (Group G : groups) {
            if (_isPurelyTextual(G)) {
                if (_isAClickableGroup__2(G)&&_hasUniformContent(G)) { result.add(G); }
            }
            if (_isPurelyImage(G)) {
                if (_isAClickableGroup__2(G)) {
                    if (isStyHomog(G)) { result.add(G); }
                }
            }
            if (!_isPurelyImage(G) && !_isPurelyTextual(G)) {
                if (_isAClickableGroup__2(G) && isStyHomog(G, false) ) { result.add(G); }
            }
        }
        for (Group g:result) g.role = "nav";
        return result;
    }

    private static boolean isStyHomog(Group g) {
        return isStyHomog(g, true);
    }

    public static int getClickablesCount(Group g) {
        int count = 0;
        for (ROI R : g.ROIs) {
            if (R.isClickable) {
                count++;
            }
        }
        return count;
    }

    public static boolean _isDimensionallyHomogeneous(Group g) {
        List<Integer> lefts = new ArrayList<>(), rights = new ArrayList<>(),
                tops = new ArrayList<>(), bottoms = new ArrayList<>();
        List<Integer> areas = new ArrayList<>();
        for (ROI R : g.ROIs) {
            lefts.add(R.x1); rights.add(R.x2); tops.add(R.y1); bottoms.add(R.y2);
            areas.add(R.getArea());
        }
        int min = Collections.min(areas), max = Collections.max(areas);

        return (1.0*max/min)<10;
    }

//    public List<ROI> extractHeadings(Group g) {
//        class DPrime implements DistanceMetric {
//            @Override public boolean isSubadditive() { return true; }
//            @Override public boolean isIndiscemible() { return true; }
//            @Override public boolean isSymmetric() { return true; }
//            @Override public double metricBound() { return Double.POSITIVE_INFINITY; }
//            @Override public String toString() { return "DPrime"; }
//            @Override public DPrime clone() { return new DPrime(); }
//            @Override public boolean supportsAcceleration() { return false; }
//            @Override public List<Double> getAccelerationCache(List<? extends Vec> vecs) { return null; }
//            @Override public List<Double> getAccelerationCache(List<? extends Vec> list, ExecutorService executorService) { return null; }
//            @Override public List<Double> getQueryInfo(Vec vec) { return null; }
//            @Override public double dist(int a, int b, List<? extends Vec> vecs, List<Double> cache) { return dist(vecs.get(a), vecs.get(b)); }
//            @Override public double dist(int a, Vec b, List<? extends Vec> vecs, List<Double> cache) { return dist(a, b, getQueryInfo(b), vecs, cache); }
//            @Override public double dist(int a, Vec b, List<Double> qi, List<? extends Vec> vecs, List<Double> cache) { return dist(vecs.get(a), b); }
//            public final List<ROI> ROIs;
//            private final GeometryFactory geometryFactory;
//
//            public DPrime(List<ROI> ROIs) {
//                super();
//                geometryFactory = new GeometryFactory(new PrecisionModel(1));
//                this.ROIs = new ArrayList<>(ROIs);
//            }
//
//            @Override public double dist(Vec a, Vec b) {
//                ROI A = ROIs.get((int)(a.get(0)));
//                ROI B = ROIs.get((int)(b.get(0)));
//                return distanceMetric(A, B)+pathMetric(A, B);
//            }
//
//            public double distanceMetric(ROI A, ROI B) {
//                Coordinate[] A_shell = {new Coordinate(A.x1, A.y1), new Coordinate(A.x2, A.y1),
//                        new Coordinate(A.x2, A.y2), new Coordinate(A.x1, A.y2),
//                        new Coordinate(A.x1, A.y1)};
//                Coordinate[] B_shell = {new Coordinate(B.x1, B.y1), new Coordinate(B.x2, B.y1),
//                        new Coordinate(B.x2, B.y2), new Coordinate(B.x1, B.y2),
//                        new Coordinate(B.x1, B.y1)};
//                Polygon A_poly = geometryFactory.createPolygon(A_shell);
//                Polygon B_poly = geometryFactory.createPolygon(B_shell);
//                return A_poly.distance(B_poly);
//            }
//            public double pathMetric(ROI A, ROI B) {
//                String A_xpath = A.xpath;
//                String B_xpath = B.xpath;
//                int diff = A_xpath.length() - B_xpath.length();
//                if (diff > 0) {
//                    B_xpath = String.format("%-"+(A_xpath.length())+"s", B_xpath);
//                }
//                if (diff < 0) {
//                    A_xpath = String.format("%-"+(B_xpath.length())+"s", A_xpath);
//                }
//                int score = 0;
//                for (int c=0; c<A_xpath.length(); c++) {
//                    score += (A_xpath.charAt(c) != B_xpath.charAt(c)) ? 1 : 0;
//                }
//                return score*1;
//            }
//        }
//
//        List<DataPoint> dataPoints = new ArrayList<>(g.ROIs.size());
//        int[] categoricalValues = new int[0];
//        CategoricalData[] categoricalData = {};
//        DenseVector numericalValues;
//        for (int r=0; r<g.ROIs.size(); r++) {
//            numericalValues = new DenseVector(1);
//            numericalValues.set(0, (double) r);
//            dataPoints.add(new DataPoint(numericalValues, categoricalValues, categoricalData));
//        }
//        DataSet dataset = new SimpleDataSet(dataPoints);
//        int[] clusters = new int[dataset.getSampleSize()];
//        KMeans km = new ElkanKMeans(new DPrime(g.ROIs));
//        clusters = km.cluster(dataset, 2, clusters);
//        Clusterer hdb = new HDBSCAN(new DPrime(g.ROIs), 3);
//        List<List<DataPoint>> clusters = hdb.cluster(dataset);
//        return null;
//    }

    private static boolean isStyHomog(Group g, Boolean acceptSingular) {
        List<Integer> fontWeights = new ArrayList<>();
        List<Integer> colorsR = new ArrayList<>(),
                      colorsG = new ArrayList<>(),
                      colorsB = new ArrayList<>();
        List<Integer> imageAreas = new ArrayList<>();
        List<Integer> maxImgDims = new ArrayList<>();
        Set<String> types = new HashSet<>();
        
        for (ROI R : g.ROIs) {
            if (R.type.equals("text")) {
                fontWeights.add(R.fontSize);
                colorsR.add(R.foregroundColor[0]);
                colorsG.add(R.foregroundColor[1]);
                colorsB.add(R.foregroundColor[2]);
            }
            if (R.type.equals("image")) {
                imageAreas.add(Math.abs(R.getArea()));
                maxImgDims.add(Math.max(Math.abs(R.width), Math.abs(R.height)));
            }
            types.add(R.type);
        }

        boolean imgChecked=false, imgResult=false, txtChecked=false, txtResult=false;
        int sing;
        if (acceptSingular) { sing = 0;
        } else { sing = 3; }
        if (imageAreas.size()>sing) {
            imgChecked = true;
            imgResult = (Collections.max(maxImgDims)<=64)&&(Collections.max(imageAreas)/Collections.min(imageAreas))<3;
        }

        if (txtChecked) return txtResult;
        if (imgChecked) return imgResult;
        return false;
    }

    private static boolean _isPurelyTextual(Group g) {
        for (ROI r : g.ROIs) {
            if (!r.type.equals("text")) return false;
        }
        return true;
    }

    public static List<Group> getAll(Mat screenshot, List<Group> groups, List<ROI> rois, Browser browser) throws Exception {
        List<Group> nav = getNav(groups);
        Group main = getMain(groups, rois);
        Group footer = getFooter(browser, groups, rois);
        List<Group> search = getSearch(screenshot, groups, rois);
        List<Group> allMarked = new ArrayList<>();
        if (nav!=null) allMarked.addAll(nav);
        if (search!=null) allMarked.addAll(search);
        if (footer!=null) allMarked.add(footer);
        if (main!=null) allMarked.add(main);
        return allMarked;
    }


    public static Group findNav(List<Group> roots) {
        Comparator<Group> cmp = (Group a, Group b) -> (int)(-a.textCount()*getClickablesRatio(a)*getClickablesCount(a)/(a.getDistance()+getContentVariance(a))
                                                            + b.textCount()*getClickablesRatio(b)*getClickablesCount(b)/(b.getDistance()+getContentVariance(b)));
        Group a; Rectangle bounds = GroupsProcessor.getBounds(roots);
        double docY, gY;
        docY = bounds.getCenterY();
        List<Group> groups = new ArrayList<>(roots);
        Collections.sort(groups, cmp);
        for (Group root : roots) {
            gY = root.bbox.getCenterY();
            if (gY>docY) groups.remove(root);
        }
        for (int i=0; i<groups.size(); i++) {
            a = groups.get(i);
            double score = a.textCount()*getClickablesRatio(a)*getClickablesCount(a)/(a.getDistance()+getContentVariance(a));
        }
        if (groups.size()>0 && groups.get(0).bbox.getCenterY()<docY) {
            Group result = groups.get(0);
            return result;
        } else {
            return null;
        }
    }

    public static Group getFooter(Browser browser, List<Group> groups, List<ROI> allROIs) {
        List<Group> candidates = new ArrayList<>();
        long lowerBound = (long)browser.executeScript("return parseInt(Array.from(document.querySelectorAll('*')).sort((a,b)=>b.getBoundingClientRect().bottom-a.getBoundingClientRect().bottom)[0].getBoundingClientRect().bottom);");
        List<ROI> lowerBoundROIs = new ArrayList<>();
        int roiLowerBound = 0;
        for (ROI r : allROIs) {
//            if (r.y2>r.documentHeight) continue; // added
            if (!r.type.startsWith("text")) continue;
            if (r.y2>roiLowerBound) {
                roiLowerBound = r.y2;
                lowerBoundROIs.clear();
                lowerBoundROIs.add(r);
            }
            if (r.y2==roiLowerBound) {
                lowerBoundROIs.add(r);
            }
        }

        groupCheck: for (Group g : groups) {
            for (ROI r : lowerBoundROIs) {
                if (g.contains(r) && g.bbox.y>(lowerBound/2)) {
                    candidates.add(g);
                    continue groupCheck;
                }
            }
        }
//        for (Group g : groups) {
//            if (g.bbox.y+g.bbox.height>lowerBound) lowerBound = g.bbox.y+g.bbox.height;
//            if (Math.abs(g.getArea())>maxArea) maxArea = Math.abs(g.getArea());
//        }
//        for (Group g : groups) {
//            if (/*_isAClickableGroup__2(g) &&*/ g.bbox.y+Math.abs(g.bbox.height)>=0.9*lowerBound
//                                         &&  Math.abs(g.getArea())<=0.3*maxArea) {
//                candidates.add(g);
//            }
//        }
        if (candidates.size()==0) {
            return null;
        } else {
            Comparator<Group> cmp = (Group a, Group b) -> (int)(-a.getDistance()*Math.pow(Math.abs(a.getArea()), 1)
                    + b.getDistance()*  Math.pow(Math.abs(b.getArea()), 1) );
            Collections.sort(candidates, cmp);
            Group result = new Group(candidates.get(0));
            result.role = "footer";
            return result;
        }
    }

    public static boolean isSearch(Mat image) throws Exception {
        String simpleMlp = new ClassPathResource("search_detector.h5").getFile().getPath();
        MultiLayerNetwork model = KerasModelImport.importKerasSequentialModelAndWeights(simpleMlp);
        Mat flat = new Mat(image.size(), CvType.CV_8UC1);
        Imgproc.cvtColor(image, flat, Imgproc.COLOR_BGR2GRAY);
        Mat cnnInput = new Mat(32, 32, CvType.CV_8UC1);
        Imgproc.resize(flat, cnnInput, cnnInput.size());

        NativeImageLoader loader = new NativeImageLoader(32, 32, 1);
        INDArray in = loader.asMatrix(cnnInput).div(255);
        INDArray out = model.output(in);
        boolean result = out.getFloat(1)>=0.95;
        return result;
    }

    public static List<Group[]> getIntersectionByROI(List<Group> roots) {
        List<Group[]> intersections = new ArrayList<>();
        for (Group i : roots) {
            for (Group j : roots) {
                if (i==j) continue;
                if (i.getIntersectionByROI(j).size()>0) intersections.add(new Group[]{i,j});
            }
        }
        return intersections;
    }

    public static List<Group[]> getIntersectionsByArea(List<Group> roots) {
        List<Group[]> intersections = new ArrayList<>();
        int area, A; Rectangle x;
        for (Group i : roots) {
            for (Group j : roots) {
                if (i==j) continue;
                if (i.getArea()>j.getArea()) {
                    area = (int)(j.getArea()*0.10);
                } else {
                    area = (int)(i.getArea()*0.10);
                }
                x = i.getIntersectionRegionWith(j);
                A = x.width*x.height;
                if (A >= area) intersections.add(new Group[]{i,j});
            }
        }
        return intersections;
    }

//    public static List<Group> resolveRedundancies(List<Group> roots) {
//        List<Group> resolved = new ArrayList<>(roots.size());
//        List<Boolean> uniqueness = new ArrayList<>(roots.size());
//        boolean groupIsUnique, foundTheROI;
//        List<Boolean> foundROIsList;
//
//        for (Group g : roots) {
//            groupIsUnique = false;
//            foundROIsList = new ArrayList<>(g.ROIs.size());
//
//            for (ROI r : g.ROIs) {
//                foundTheROI = false;
//                for (Group k : roots) {
//                    if (k==g) continue;
//                    if (k.containsCentroidOf(r)) {
//                        foundTheROI=true;
//                        break;
//                    }
//                }
//                foundROIsList.add(foundTheROI);
//                if (!foundTheROI) break;
//            }
//
//            for (boolean f : foundROIsList) {
//                if (!f) {
//                    groupIsUnique = true;
//                    break;
//                }
//            }
//
//            uniqueness.add(groupIsUnique);
//        }
//
//        for (int i=0; i<roots.size(); i++) {
//            if (uniqueness.get(i)==true)  resolved.add(roots.get(i));
//        }
//
//        return resolved;
//    }

    public static List<Group> resolveIntersections(List<Group> roots) {
        List<Group[]> intersections = getIntersectionsByArea(roots);
        List<Group> resolved = new ArrayList<>(roots.size());

        Rectangle region;
        Group G, G2;
        int countA, countB;
        for (Group[] x : intersections) {
            region = x[0].getIntersectionRegionWith(x[1]);
            countA = x[0].getROIsInside(region).size();
            countB = x[1].getROIsInside(region).size();
            if (countA==0) {
                G = new Group(x[0]);
                G.shrinkToFitContent();
                resolved.add(G);
                resolved.add(x[1]);
                continue;
            }
            if (countB==0) {
                G = new Group(x[1]);
                G.shrinkToFitContent();
                resolved.add(x[0]);
                resolved.add(G);
                continue;
            }

            G  = new Group(x[0]);
            G2 = new Group(x[1]);
            G.shrinkToFitContent();
            G2.shrinkToFitContent();
            resolved.add(G);
            resolved.add(G2);
        }

        return resolved;
    }

    public static boolean isSearch(Mat screenshot, ROI R) throws Exception {
        if (!R.type.equalsIgnoreCase("image")) {
            return false;
        } else if (R.width>64||R.height>64||R.width/R.height>2||R.height/R.width>2) {
            return false;
        } else {
            return isSearch(screenshot.submat(
                    new Rect(R.x1, R.y1, R.width, R.height)));
        }
    }

//    public static List<Group> resolveIntersections(List<Group> roots, List<Group[]> intersections, List<ROI> globalROIs) {
//        List<Group> resolved = new ArrayList<>(roots);
//        Group A, B, _A, _B, toShrink, toKeep;
//        List<ROI> newROIs, xsection;
//        int A_x1, A_x2, A_y1, A_y2, B_x1, B_x2, B_y1, B_y2;
//        int new_x1, new_x2, new_y1, new_y2;
//        for (Group[] x : intersections) {
//            A = x[0]; B = x[1];
//            if (A.getArea()>B.getArea()) {
//                toShrink = A; toKeep = B;
//            } else {
//                toShrink = B; toKeep = A;
//            }
//            int idx = resolved.indexOf(toShrink);
//            xsection = A.getIntersectionByROI(B);
//            newROIs = new ArrayList<>(toShrink.ROIs);
//            newROIs.removeAll(xsection);
//            _A=toKeep; _B=toShrink;
//            A_x1=_A.bbox.x; A_x2=A_x1+_A.bbox.width; A_y1=_A.bbox.y; A_y2=A_y1+_A.bbox.height;
//            B_x1=_B.bbox.x; B_x2=B_x1+_B.bbox.width; B_y1=_B.bbox.y; B_y2=B_y1+_B.bbox.height;
//            new_x1 = B_x1; new_x2 = B_x2; new_y1 = B_y1; new_y2 = B_y2;
//            if (A_x1 < B_x1 && B_x1 < A_x2) { // left intersection
//                new_x1 = A_x2+1;
//            }
//            if (A_x1 < B_x2 && B_x2 < A_x2) { // right intersection
//                new_x2 = A_x1-1;
//            }
//            if (A_y1 < B_y2 && B_y2 < A_y2) { // bottom intersection
//                new_y2 = A_y1-1;
//            }
//            if (A_y1 < B_y1 && B_y1 < A_y2) { // top intersection
//                new_y1 = A_y2+1;
//            }
//            toShrink = new Group(toShrink);
//            toShrink.bbox = new Rectangle(new_x1, new_y1, new_x2-new_x1, new_y2-new_y1);
//            toShrink.ROIs = newROIs;
//            resolved.set(idx, toShrink);
//        }
//        return resolved;
//    }

    public static List<Group> getSearch(Mat screenshot, List<Group> allGlobalGroups, List<ROI> allGlobalROIs) throws Exception {
        List<ROI> potentialSearchElements = ROI.filterByType(allGlobalROIs,
                new String[]{"input - type=text", "input - type=search"});
        List<ROI> confirmedSearchElements = new ArrayList<>(allGlobalROIs.size());
        List<Group> output = new ArrayList<>();
        GeometryFactory factory = new GeometryFactory(new PrecisionModel(1));
        STRtree tree = new STRtree();
        Geometry g;
        for (ROI R : allGlobalROIs) {
            g = factory.createPolygon(new Coordinate[]{
                    new Coordinate(R.x1, R.y1),
                    new Coordinate(R.x2, R.y1),
                    new Coordinate(R.x2, R.y2),
                    new Coordinate(R.x1, R.y2),
                    new Coordinate(R.x1, R.y1)});
            tree.insert(g.getEnvelopeInternal(), R);
        }

        String content; List<ROI> neighbors = new ArrayList<>(); Object[] temp;
        for (ROI R : potentialSearchElements) {
            content = R.type.substring(R.type.lastIndexOf("-"));
            if (R.type.contains("type=search")) {
                confirmedSearchElements.add(R);
                continue;
            }

            if (content.toLowerCase().contains("search")) {
                confirmedSearchElements.add(R);
                continue;
            }

            g = factory.createPolygon(new Coordinate[]{
                    new Coordinate(R.x1, R.y1),
                    new Coordinate(R.x2, R.y1),
                    new Coordinate(R.x2, R.y2),
                    new Coordinate(R.x1, R.y2),
                    new Coordinate(R.x1, R.y1)});
            temp = tree.nearestNeighbour(g.getEnvelopeInternal(), R, R, 4);
            for (Object t : temp) { neighbors.add((ROI)t); }
            for (ROI n : neighbors) {
                if (n.content.toLowerCase().contains("search")) {
                    confirmedSearchElements.add(R);
                    continue;
                }

                if (isSearch(screenshot, n)) {
                    confirmedSearchElements.add(R);
                    continue;
                }
            }
        }

        if (confirmedSearchElements.size()>0) {
            List<Group> result = allGlobalGroups.stream()
                    .filter(group -> group.contains(confirmedSearchElements.get(0)))
                    .sorted(Comparator.comparingInt(Group::getArea))
                    .collect(Collectors.toList());

//            return result.size()>0 ? result.get(0) : null;
            if (result.size()>0) {
                output.add(result.get(0));
                for (Group o:output) o.role = "search";
                return output;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public static List<Group> getSubheadings(Group root, List<Group> allGlobalGroups) {
        return getSubheadings(root, allGlobalGroups, null);
    }

    public static List<Group> getSubheadings(Group root, List<Group> allGlobalGroups, Mat screenshot) {
        List<Group> rootSubgroups = new ArrayList<>(allGlobalGroups.size());
        for (Group G : allGlobalGroups) {
            if (root.contains(G) && root != G) {
                rootSubgroups.add(G);
            }
        }
        List<Group> subroots = GroupTree.getRoots(rootSubgroups, root.ROIs, true);
        List<Group> result = GroupTree.pruneByContainment(subroots);
        return result;
//        return subroots;
    }

    private static boolean _isPurelyImage(Group g) {
        for (ROI r : g.ROIs) {
            if (!r.type.equals("image")) return false;
        }
        return true;
    }
}