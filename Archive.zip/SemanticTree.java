package org.icse2020.axeray;

import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SemanticTree {

    public static List<List<Group>> buildTree(
                        Map<Group, String> roles,
                        List<Group> roots,
                        List<Group> allGlobalGroups,
                        Mat screenshot) {
        Group treeRoot = new Group();
        Group main=null;
        List<List<Group>> flatList = new ArrayList<>();
        flatList.add(new ArrayList<>()); // index 0 (level 1)
        flatList.add(new ArrayList<>()); // index 1 (level 2)

        for(Map.Entry<Group, String> node : roles.entrySet()) {
            node.getKey().role = node.getValue();

            if (node.getValue().equals("main")) {
                main = node.getKey();
                node.getKey().level = 1; flatList.get(0).add(node.getKey());
                treeRoot.children.add(node.getKey());
                continue;
            }

            if (node.getValue().equals("navigation")) {
                node.getKey().level = 1; flatList.get(0).add(node.getKey());
                treeRoot.children.add(node.getKey());
                continue;
            }

            if (node.getValue().equals("footer")) {
                node.getKey().level = 1; flatList.get(0).add(node.getKey());
                treeRoot.children.add(node.getKey());
                continue;
            }

            if (node.getValue().equals("search")) {
                for (Group root : roots) {
                    if (node.getKey().isContainedBy(root)) {
                        node.getKey().level = 2; flatList.get(1).add(node.getKey());
                        root.children.add(node.getKey());
                        node.getKey().parent = root;
                        break;
                    }
                }
                if (node.getKey().level == -1) {
                    node.getKey().level = 1; flatList.get(0).add(node.getKey());
                    treeRoot.children.add(node.getKey());
                }
                continue;
            }
            node.getKey().level = 1; flatList.get(0).add(node.getKey());
            treeRoot.children.add(node.getKey());
        }

        if (main!=null) {
            List<Group> rawSubgroups, subgroups;
            Group getSubheadingsFor = main;
            for (int i = 0; i<5; i++) {
                rawSubgroups = Marker.getSubheadings(getSubheadingsFor, allGlobalGroups, screenshot);
                subgroups = rawSubgroups;
                if (subgroups.size()==1) {
                    getSubheadingsFor = subgroups.get(0);
                    continue;
                }
                if (subgroups.size()==0) {
                    break;
                }
                if (subgroups.size()>1) {
                    main.children.addAll(subgroups);
                    for (Group g : subgroups) {
                        g.level = 2; g.parent = main;
                        flatList.get(1).add(g);
                    }
                    break;
                }
            }
        }
        return flatList;
    }

    public static void renderTree(List<List<Group>> tree, Mat screenshot, String title) {
        Map<Group, String> h1PlotMap = new HashMap<>();
        Map<Group, String> h2PlotMap = new HashMap<>();
        List<Group> h1 = tree.get(0);
        List<Group> h2 = tree.get(1);
        for (Group g : h1) {
            h1PlotMap.put(g, g.role);
        }
        for (Group k : h2) {
            h2PlotMap.put(k, k.role);
        }

        Mat image = new Mat(screenshot.size(), screenshot.type());
        int labelX=0, labelY=0;
        Rectangle box = new Rectangle();
        int colorIndex = 0;
        int hLevel = 1;
        for (List<Group> groups : new List[]{h1, h2}) {
            for (int i=0; i<groups.size(); i++) {
                if (hLevel==1) box = Util.padRect(groups.get(i).bbox, 5, screenshot);
                if (hLevel==2) box = Util.padRect(groups.get(i).bbox, -1, screenshot);
                Imgproc.rectangle(image,
                        new org.opencv.core.Point(box.x, box.y),
                        new org.opencv.core.Point(box.x+box.width, box.y+box.height),
                        Colormap.get(colorIndex), -1);
                Imgproc.rectangle(image,
                        new org.opencv.core.Point(box.x, box.y),
                        new org.opencv.core.Point(box.x+box.width, box.y+box.height),
                        new Scalar(0,0,0, 255), 1);
                colorIndex++;
            }
            hLevel++;
        }
        image = Util.overlay(image, 0.6, screenshot, 0.4);
        hLevel = 1;
        String label="";
        for (List<Group> groups : new List[]{h1, h2}) {
            for (int i=0; i<groups.size(); i++) {
                box = groups.get(i).bbox;
                if (hLevel==1) labelX = box.x + 0;
                if (hLevel==2) labelX = box.x + (box.width/2) - 40;
                if (hLevel==1) labelY = box.y - 10;
                if (hLevel==2) labelY = box.y + 20;

                if (hLevel==2 && groups.get(i).role.equals("region")) {
                    label = "sub-region";
                } else if (hLevel==1 && groups.get(i).role.equals("region")) {
                    label = "";
                } else {
                    label = groups.get(i).role;
                }
                Imgproc.putText(image, label, new org.opencv.core.Point(labelX-1,labelY), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
                Imgproc.putText(image, label, new org.opencv.core.Point(labelX+1,labelY), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
                Imgproc.putText(image, label, new org.opencv.core.Point(labelX,labelY-1), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
                Imgproc.putText(image, label, new org.opencv.core.Point(labelX,labelY+1), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,191,255, 255),3);
                Imgproc.putText(image, label, new Point(labelX,labelY), Imgproc.FONT_HERSHEY_SIMPLEX,0.5, new Scalar(0,0,0, 255),1);
            }
            hLevel++;
        }
        Util.displayMat(image, title, false);
    }
}