package org.icse2020.axeray;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) {
        try {
            WebDriverManager.chromedriver().setup();
            Browser browser = new Browser(false);
            browser.get(args[0]);
            Root.apply(browser);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
